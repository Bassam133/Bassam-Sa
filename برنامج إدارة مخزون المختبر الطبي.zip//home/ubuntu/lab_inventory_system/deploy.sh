#!/bin/bash

# سكريبت نشر نظام إدارة مخزون المختبر الطبي

echo "بدء عملية نشر نظام إدارة مخزون المختبر الطبي..."

# إنشاء المجلد للنشر
DEPLOY_DIR="/var/www/lab_inventory_system"
echo "إنشاء مجلد النشر: $DEPLOY_DIR"
sudo mkdir -p $DEPLOY_DIR

# نسخ ملفات المشروع
echo "نسخ ملفات المشروع..."
sudo cp -r /home/ubuntu/lab_inventory_system/* $DEPLOY_DIR/

# تثبيت المتطلبات
echo "تثبيت المتطلبات..."
cd $DEPLOY_DIR
sudo pip3 install -r requirements.txt

# إنشاء قاعدة البيانات
echo "إنشاء قاعدة البيانات..."
cd $DEPLOY_DIR
export FLASK_APP=run.py
sudo -E python3 -c "from app import create_app, db; app = create_app(); app.app_context().push(); db.create_all()"

# إنشاء مستخدم مدير
echo "إنشاء مستخدم مدير..."
sudo -E python3 -c "
from app import create_app, db
from app.models.models import User
app = create_app()
with app.app_context():
    # التحقق من عدم وجود المستخدم مسبقاً
    user = User.query.filter_by(username='admin').first()
    if not user:
        user = User(username='admin', password='admin123', full_name='مدير النظام', email='admin@example.com', role='admin')
        db.session.add(user)
        db.session.commit()
        print('تم إنشاء المستخدم بنجاح')
    else:
        print('المستخدم موجود بالفعل')
"

# إضافة بيانات أولية
echo "إضافة بيانات أولية..."
sudo -E python3 -c "
from app import create_app, db
from app.models.models import Category, Manufacturer, NotificationSetting
app = create_app()
with app.app_context():
    # إضافة إعدادات التنبيهات
    settings = NotificationSetting.query.first()
    if not settings:
        settings = NotificationSetting(days_before_expiry=30, email_notifications=False)
        db.session.add(settings)
    
    # إضافة فئات المنتجات
    categories = [
        Category(name='كواشف', description='كواشف ومواد كيميائية للتحاليل'),
        Category(name='أدوات', description='أدوات وأجهزة مخبرية'),
        Category(name='مستهلكات', description='مواد مستهلكة للمختبر')
    ]
    
    for category in categories:
        existing = Category.query.filter_by(name=category.name).first()
        if not existing:
            db.session.add(category)
    
    # إضافة الشركات المصنعة
    manufacturers = [
        Manufacturer(name='شركة الأجهزة الطبية', contact_person='أحمد محمد', phone='0123456789'),
        Manufacturer(name='شركة المواد الكيميائية', contact_person='سارة أحمد', phone='0123456788')
    ]
    
    for manufacturer in manufacturers:
        existing = Manufacturer.query.filter_by(name=manufacturer.name).first()
        if not existing:
            db.session.add(manufacturer)
    
    db.session.commit()
    print('تم إضافة البيانات الأولية بنجاح')
"

# إنشاء ملف خدمة systemd
echo "إنشاء ملف خدمة systemd..."
sudo bash -c 'cat > /etc/systemd/system/lab_inventory.service << EOL
[Unit]
Description=Lab Inventory Management System
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/lab_inventory_system
ExecStart=/usr/bin/python3 /var/www/lab_inventory_system/run.py
Restart=always

[Install]
WantedBy=multi-user.target
EOL'

# تفعيل وتشغيل الخدمة
echo "تفعيل وتشغيل الخدمة..."
sudo systemctl daemon-reload
sudo systemctl enable lab_inventory.service
sudo systemctl start lab_inventory.service

echo "تم نشر النظام بنجاح!"
echo "يمكنك الوصول إلى النظام على العنوان: http://localhost:5000"
echo "اسم المستخدم: admin"
echo "كلمة المرور: admin123"
echo ""
echo "للتحقق من حالة الخدمة، استخدم الأمر: sudo systemctl status lab_inventory.service"
