-- مخطط قاعدة البيانات لنظام إدارة مخزون المختبر الطبي

-- جدول المستخدمين
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT,
    role TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- جدول فئات المنتجات
CREATE TABLE categories (
    category_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT
);

-- جدول الشركات المصنعة
CREATE TABLE manufacturers (
    manufacturer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact_person TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    notes TEXT
);

-- جدول المنتجات
CREATE TABLE products (
    product_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    catalog_number TEXT,
    category_id INTEGER,
    manufacturer_id INTEGER,
    unit TEXT NOT NULL,
    storage_conditions TEXT,
    min_quantity INTEGER DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(manufacturer_id)
);

-- جدول المخزون (يحتوي على معلومات التشغيلة وتواريخ الإنتاج والانتهاء)
CREATE TABLE inventory_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    lot_number TEXT NOT NULL,
    barcode TEXT,
    quantity REAL NOT NULL,
    location TEXT,
    production_date DATE,
    expiry_date DATE NOT NULL,
    received_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- جدول حركة المخزون (الإضافات والسحب)
CREATE TABLE inventory_transactions (
    transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER NOT NULL,
    transaction_type TEXT NOT NULL, -- 'in' للإضافة، 'out' للسحب
    quantity REAL NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER NOT NULL,
    notes TEXT,
    FOREIGN KEY (item_id) REFERENCES inventory_items(item_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- جدول إعدادات التنبيهات
CREATE TABLE notification_settings (
    setting_id INTEGER PRIMARY KEY AUTOINCREMENT,
    days_before_expiry INTEGER NOT NULL DEFAULT 30,
    email_notifications BOOLEAN DEFAULT 0,
    user_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- جدول التنبيهات
CREATE TABLE notifications (
    notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER NOT NULL,
    notification_type TEXT NOT NULL, -- 'expiry' للانتهاء، 'low_stock' للمخزون المنخفض
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory_items(item_id)
);
