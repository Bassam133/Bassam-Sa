from app import create_app, db
from app.models.models import User, Category, Manufacturer, Product, InventoryItem, NotificationSetting
from flask_migrate import upgrade
import os
import click

app = create_app()

@app.cli.command('init-db')
def init_db():
    """تهيئة قاعدة البيانات وإنشاء الجداول"""
    db.create_all()
    click.echo('تم تهيئة قاعدة البيانات بنجاح.')

@app.cli.command('create-admin')
@click.option('--username', prompt=True, help='اسم المستخدم للمدير')
@click.option('--password', prompt=True, hide_input=True, confirmation_prompt=True, help='كلمة المرور للمدير')
@click.option('--fullname', prompt=True, help='الاسم الكامل للمدير')
@click.option('--email', prompt=True, help='البريد الإلكتروني للمدير')
def create_admin(username, password, fullname, email):
    """إنشاء حساب مدير النظام"""
    user = User(
        username=username,
        password=password,
        full_name=fullname,
        email=email,
        role='admin'
    )
    db.session.add(user)
    db.session.commit()
    click.echo(f'تم إنشاء حساب المدير {username} بنجاح.')

@app.cli.command('seed-data')
def seed_data():
    """إضافة بيانات أولية للنظام"""
    # إضافة فئات المنتجات
    categories = [
        Category(name='كواشف', description='كواشف ومواد كيميائية للتحاليل'),
        Category(name='أدوات', description='أدوات وأجهزة مخبرية'),
        Category(name='مستهلكات', description='مواد مستهلكة للمختبر'),
        Category(name='محاليل', description='محاليل ومواد للمعايرة')
    ]
    
    for category in categories:
        db.session.add(category)
    
    # إضافة الشركات المصنعة
    manufacturers = [
        Manufacturer(name='شركة الأجهزة الطبية', contact_person='أحمد محمد', phone='0123456789'),
        Manufacturer(name='شركة المواد الكيميائية', contact_person='سارة أحمد', phone='0123456788'),
        Manufacturer(name='شركة المستلزمات المخبرية', contact_person='محمد علي', phone='0123456787')
    ]
    
    for manufacturer in manufacturers:
        db.session.add(manufacturer)
    
    # إضافة إعدادات التنبيهات الافتراضية
    notification_setting = NotificationSetting(
        days_before_expiry=30,
        email_notifications=False
    )
    db.session.add(notification_setting)
    
    db.session.commit()
    click.echo('تم إضافة البيانات الأولية بنجاح.')

@app.cli.command('check-notifications')
def check_notifications():
    """فحص المنتجات التي ستنتهي صلاحيتها قريبًا وإنشاء تنبيهات"""
    from app.utils.notifications import check_expiring_items, check_low_stock
    with app.app_context():
        check_expiring_items()
        check_low_stock()
    click.echo('تم فحص المنتجات وإنشاء التنبيهات بنجاح.')

@app.shell_context_processor
def make_shell_context():
    """توفير سياق للصدفة التفاعلية"""
    return {
        'db': db, 
        'User': User, 
        'Category': Category, 
        'Manufacturer': Manufacturer,
        'Product': Product,
        'InventoryItem': InventoryItem
    }

@app.before_first_request
def create_tables():
    """إنشاء الجداول قبل أول طلب"""
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
