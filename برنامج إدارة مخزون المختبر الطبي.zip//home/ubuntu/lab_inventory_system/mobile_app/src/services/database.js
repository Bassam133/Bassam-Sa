import * as SQLite from 'expo-sqlite';

// Open or create the database
const db = SQLite.openDatabase('lab_inventory.db');

// Initialize the database by creating tables
export const initDatabase = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      // Create users table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,
          name TEXT NOT NULL,
          role TEXT NOT NULL
        );`,
        [],
        () => {
          console.log('Users table created successfully');
        },
        (_, error) => {
          console.error('Error creating users table:', error);
          reject(error);
        }
      );

      // Create categories table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS categories (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE
        );`,
        [],
        () => {
          console.log('Categories table created successfully');
        },
        (_, error) => {
          console.error('Error creating categories table:', error);
          reject(error);
        }
      );

      // Create manufacturers table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS manufacturers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          contact TEXT
        );`,
        [],
        () => {
          console.log('Manufacturers table created successfully');
        },
        (_, error) => {
          console.error('Error creating manufacturers table:', error);
          reject(error);
        }
      );

      // Create products table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS products (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          description TEXT,
          category_id INTEGER,
          manufacturer_id INTEGER,
          created_at TEXT NOT NULL,
          FOREIGN KEY (category_id) REFERENCES categories (id),
          FOREIGN KEY (manufacturer_id) REFERENCES manufacturers (id)
        );`,
        [],
        () => {
          console.log('Products table created successfully');
        },
        (_, error) => {
          console.error('Error creating products table:', error);
          reject(error);
        }
      );

      // Create inventory table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS inventory (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          lot_number TEXT NOT NULL,
          production_date TEXT NOT NULL,
          expiry_date TEXT NOT NULL,
          quantity INTEGER NOT NULL,
          location TEXT,
          notes TEXT,
          created_at TEXT NOT NULL,
          FOREIGN KEY (product_id) REFERENCES products (id)
        );`,
        [],
        () => {
          console.log('Inventory table created successfully');
        },
        (_, error) => {
          console.error('Error creating inventory table:', error);
          reject(error);
        }
      );

      // Create inventory_movements table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS inventory_movements (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          inventory_id INTEGER NOT NULL,
          movement_type TEXT NOT NULL,
          quantity INTEGER NOT NULL,
          notes TEXT,
          created_at TEXT NOT NULL,
          user_id INTEGER NOT NULL,
          FOREIGN KEY (inventory_id) REFERENCES inventory (id),
          FOREIGN KEY (user_id) REFERENCES users (id)
        );`,
        [],
        () => {
          console.log('Inventory movements table created successfully');
        },
        (_, error) => {
          console.error('Error creating inventory movements table:', error);
          reject(error);
        }
      );

      // Create notifications table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS notifications (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          type TEXT NOT NULL,
          related_id INTEGER,
          read INTEGER DEFAULT 0,
          created_at TEXT NOT NULL
        );`,
        [],
        () => {
          console.log('Notifications table created successfully');
          resolve();
        },
        (_, error) => {
          console.error('Error creating notifications table:', error);
          reject(error);
        }
      );
    });
  });
};

// Get all products
export const getProducts = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT p.*, c.name as category_name, m.name as manufacturer_name
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN manufacturers m ON p.manufacturer_id = m.id
         ORDER BY p.name;`,
        [],
        (_, { rows }) => {
          resolve(rows._array);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get product by ID
export const getProductById = (id) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT p.*, c.name as category_name, m.name as manufacturer_name
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN manufacturers m ON p.manufacturer_id = m.id
         WHERE p.id = ?;`,
        [id],
        (_, { rows }) => {
          if (rows.length > 0) {
            resolve(rows._array[0]);
          } else {
            resolve(null);
          }
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Add a new product
export const addProduct = (product) => {
  return new Promise((resolve, reject) => {
    const { name, description, category_id, manufacturer_id } = product;
    const created_at = new Date().toISOString();

    db.transaction(tx => {
      tx.executeSql(
        `INSERT INTO products (name, description, category_id, manufacturer_id, created_at)
         VALUES (?, ?, ?, ?, ?);`,
        [name, description, category_id, manufacturer_id, created_at],
        (_, { insertId }) => {
          resolve(insertId);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Update a product
export const updateProduct = (product) => {
  return new Promise((resolve, reject) => {
    const { id, name, description, category_id, manufacturer_id } = product;

    db.transaction(tx => {
      tx.executeSql(
        `UPDATE products
         SET name = ?, description = ?, category_id = ?, manufacturer_id = ?
         WHERE id = ?;`,
        [name, description, category_id, manufacturer_id, id],
        () => {
          resolve();
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Delete a product
export const deleteProduct = (id) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `DELETE FROM products WHERE id = ?;`,
        [id],
        () => {
          resolve();
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get all inventory items
export const getInventory = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT i.*, p.name as product_name
         FROM inventory i
         JOIN products p ON i.product_id = p.id
         ORDER BY i.expiry_date;`,
        [],
        (_, { rows }) => {
          resolve(rows._array);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get inventory items by product ID
export const getInventoryByProductId = (productId) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT i.*, p.name as product_name
         FROM inventory i
         JOIN products p ON i.product_id = p.id
         WHERE i.product_id = ?
         ORDER BY i.expiry_date;`,
        [productId],
        (_, { rows }) => {
          resolve(rows._array);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Add a new inventory item
export const addInventoryItem = (item) => {
  return new Promise((resolve, reject) => {
    const { product_id, lot_number, production_date, expiry_date, quantity, location, notes } = item;
    const created_at = new Date().toISOString();

    db.transaction(tx => {
      tx.executeSql(
        `INSERT INTO inventory (product_id, lot_number, production_date, expiry_date, quantity, location, notes, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,
        [product_id, lot_number, production_date, expiry_date, quantity, location, notes, created_at],
        (_, { insertId }) => {
          resolve(insertId);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Update an inventory item
export const updateInventoryItem = (item) => {
  return new Promise((resolve, reject) => {
    const { id, product_id, lot_number, production_date, expiry_date, quantity, location, notes } = item;

    db.transaction(tx => {
      tx.executeSql(
        `UPDATE inventory
         SET product_id = ?, lot_number = ?, production_date = ?, expiry_date = ?, quantity = ?, location = ?, notes = ?
         WHERE id = ?;`,
        [product_id, lot_number, production_date, expiry_date, quantity, location, notes, id],
        () => {
          resolve();
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Delete an inventory item
export const deleteInventoryItem = (id) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `DELETE FROM inventory WHERE id = ?;`,
        [id],
        () => {
          resolve();
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get inventory items that are about to expire
export const getExpiringInventory = (thresholdDays) => {
  return new Promise((resolve, reject) => {
    const today = new Date();
    const thresholdDate = new Date();
    thresholdDate.setDate(today.getDate() + thresholdDays);
    
    const todayStr = today.toISOString().split('T')[0];
    const thresholdStr = thresholdDate.toISOString().split('T')[0];

    db.transaction(tx => {
      tx.executeSql(
        `SELECT i.*, p.name as product_name
         FROM inventory i
         JOIN products p ON i.product_id = p.id
         WHERE i.expiry_date BETWEEN ? AND ?
         ORDER BY i.expiry_date;`,
        [todayStr, thresholdStr],
        (_, { rows }) => {
          resolve(rows._array);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get inventory items by barcode (lot number)
export const getInventoryByBarcode = (barcode) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT i.*, p.name as product_name
         FROM inventory i
         JOIN products p ON i.product_id = p.id
         WHERE i.lot_number = ?
         ORDER BY i.expiry_date;`,
        [barcode],
        (_, { rows }) => {
          resolve(rows._array);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Add a notification
export const addNotification = (notification) => {
  return new Promise((resolve, reject) => {
    const { title, message, type, related_id } = notification;
    const created_at = new Date().toISOString();

    db.transaction(tx => {
      tx.executeSql(
        `INSERT INTO notifications (title, message, type, related_id, read, created_at)
         VALUES (?, ?, ?, ?, 0, ?);`,
        [title, message, type, related_id, created_at],
        (_, { insertId }) => {
          resolve(insertId);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get all notifications
export const getNotifications = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT * FROM notifications ORDER BY created_at DESC;`,
        [],
        (_, { rows }) => {
          resolve(rows._array);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Mark notification as read
export const markNotificationAsRead = (id) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `UPDATE notifications SET read = 1 WHERE id = ?;`,
        [id],
        () => {
          resolve();
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Get unread notifications count
export const getUnreadNotificationsCount = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT COUNT(*) as count FROM notifications WHERE read = 0;`,
        [],
        (_, { rows }) => {
          resolve(rows._array[0].count);
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Insert default user if none exists
export const insertDefaultUserIfNeeded = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT COUNT(*) as count FROM users;`,
        [],
        (_, { rows }) => {
          const count = rows._array[0].count;
          if (count === 0) {
            // Insert default admin user
            tx.executeSql(
              `INSERT INTO users (username, password, name, role)
               VALUES (?, ?, ?, ?);`,
              ['admin', 'admin123', 'مدير النظام', 'admin'],
              () => {
                console.log('Default admin user created');
                resolve();
              },
              (_, error) => {
                console.error('Error creating default user:', error);
                reject(error);
              }
            );
          } else {
            resolve();
          }
        },
        (_, error) => {
          reject(error);
        }
      );
    });
  });
};

// Export the database object for direct access if needed
export default db;
