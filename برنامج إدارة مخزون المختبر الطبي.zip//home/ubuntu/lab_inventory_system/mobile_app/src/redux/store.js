import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import { persistStore, persistReducer } from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Import reducers
import productsReducer from './reducers/productsReducer';
import inventoryReducer from './reducers/inventoryReducer';
import notificationsReducer from './reducers/notificationsReducer';
import authReducer from './reducers/authReducer';

// Configure persist
const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
  whitelist: ['auth', 'products', 'inventory', 'notifications'] // what to persist
};

// Combine reducers
const rootReducer = combineReducers({
  auth: authReducer,
  products: productsReducer,
  inventory: inventoryReducer,
  notifications: notificationsReducer
});

// Create persisted reducer
const persistedReducer = persistReducer(persistConfig, rootReducer);

// Create store with middleware
export const store = createStore(
  persistedReducer,
  applyMiddleware(thunk)
);

// Create persistor
export const persistor = persistStore(store);
