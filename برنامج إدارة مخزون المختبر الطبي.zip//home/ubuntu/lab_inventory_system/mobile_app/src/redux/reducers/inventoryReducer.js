// Initial state
const initialState = {
  inventory: [],
  loading: false,
  error: null
};

// Action types
const FETCH_INVENTORY_REQUEST = 'FETCH_INVENTORY_REQUEST';
const FETCH_INVENTORY_SUCCESS = 'FETCH_INVENTORY_SUCCESS';
const FETCH_INVENTORY_FAILURE = 'FETCH_INVENTORY_FAILURE';
const ADD_INVENTORY_ITEM = 'ADD_INVENTORY_ITEM';
const UPDATE_INVENTORY_ITEM = 'UPDATE_INVENTORY_ITEM';
const DELETE_INVENTORY_ITEM = 'DELETE_INVENTORY_ITEM';

// Reducer
const inventoryReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_INVENTORY_REQUEST:
      return {
        ...state,
        loading: true,
        error: null
      };
    case FETCH_INVENTORY_SUCCESS:
      return {
        ...state,
        loading: false,
        inventory: action.payload
      };
    case FETCH_INVENTORY_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload
      };
    case ADD_INVENTORY_ITEM:
      return {
        ...state,
        inventory: [...state.inventory, action.payload]
      };
    case UPDATE_INVENTORY_ITEM:
      return {
        ...state,
        inventory: state.inventory.map(item => 
          item.id === action.payload.id ? action.payload : item
        )
      };
    case DELETE_INVENTORY_ITEM:
      return {
        ...state,
        inventory: state.inventory.filter(item => item.id !== action.payload)
      };
    default:
      return state;
  }
};

export default inventoryReducer;
