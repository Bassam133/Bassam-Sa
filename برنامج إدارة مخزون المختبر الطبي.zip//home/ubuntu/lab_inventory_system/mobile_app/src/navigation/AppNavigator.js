import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { Button } from 'react-native-paper';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { I18nManager } from 'react-native';

// Screens
import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/HomeScreen';
import ProductsScreen from '../screens/ProductsScreen';
import AddProductScreen from '../screens/AddProductScreen';
import InventoryScreen from '../screens/InventoryScreen';
import AddInventoryScreen from '../screens/AddInventoryScreen';
import BarcodeScreen from '../screens/BarcodeScreen';
import NotificationsScreen from '../screens/NotificationsScreen';
import ReportsScreen from '../screens/ReportsScreen';
import SettingsScreen from '../screens/SettingsScreen';

// Force RTL layout for Arabic
I18nManager.forceRTL(true);

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Stack navigators for each tab
const HomeStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="HomeMain" component={HomeScreen} />
  </Stack.Navigator>
);

const ProductsStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="ProductsList" component={ProductsScreen} />
    <Stack.Screen name="AddProduct" component={AddProductScreen} />
    <Stack.Screen name="ProductDetail" component={ProductDetailPlaceholder} />
  </Stack.Navigator>
);

const InventoryStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="InventoryList" component={InventoryScreen} />
    <Stack.Screen name="AddInventory" component={AddInventoryScreen} />
    <Stack.Screen name="InventoryDetail" component={InventoryDetailPlaceholder} />
  </Stack.Navigator>
);

const BarcodeStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="BarcodeMain" component={BarcodeScreen} />
  </Stack.Navigator>
);

const ReportsStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}
  >
    <Stack.Screen name="ReportsMain" component={ReportsScreen} />
  </Stack.Navigator>
);

// Placeholder components for screens not yet implemented
const ProductDetailPlaceholder = () => (
  <View style={styles.placeholderContainer}>
    <Text style={styles.placeholderText}>تفاصيل المنتج</Text>
    <Text style={styles.placeholderSubtext}>هذه الشاشة قيد التطوير</Text>
  </View>
);

const InventoryDetailPlaceholder = () => (
  <View style={styles.placeholderContainer}>
    <Text style={styles.placeholderText}>تفاصيل المخزون</Text>
    <Text style={styles.placeholderSubtext}>هذه الشاشة قيد التطوير</Text>
  </View>
);

// Main tab navigator
const MainTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Products') {
            iconName = focused ? 'cube' : 'cube-outline';
          } else if (route.name === 'Inventory') {
            iconName = focused ? 'list' : 'list-outline';
          } else if (route.name === 'Barcode') {
            iconName = focused ? 'barcode' : 'barcode-outline';
          } else if (route.name === 'Reports') {
            iconName = focused ? 'bar-chart' : 'bar-chart-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#3498db',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,
        tabBarStyle: {
          backgroundColor: 'white',
          borderTopWidth: 1,
          borderTopColor: '#e0e0e0',
          paddingBottom: 5,
          paddingTop: 5,
        },
        tabBarLabelStyle: {
          fontSize: 12,
        },
      })}
    >
      <Tab.Screen 
        name="Home" 
        component={HomeStack} 
        options={{ tabBarLabel: 'الرئيسية' }}
      />
      <Tab.Screen 
        name="Products" 
        component={ProductsStack} 
        options={{ tabBarLabel: 'المنتجات' }}
      />
      <Tab.Screen 
        name="Inventory" 
        component={InventoryStack} 
        options={{ tabBarLabel: 'المخزون' }}
      />
      <Tab.Screen 
        name="Barcode" 
        component={BarcodeStack} 
        options={{ tabBarLabel: 'الباركود' }}
      />
      <Tab.Screen 
        name="Reports" 
        component={ReportsStack} 
        options={{ tabBarLabel: 'التقارير' }}
      />
    </Tab.Navigator>
  );
};

// Root navigator
const AppNavigator = () => {
  // Simulating authentication state
  const isAuthenticated = false;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isAuthenticated ? (
          <>
            <Stack.Screen name="Main" component={MainTabNavigator} />
            <Stack.Screen name="Notifications" component={NotificationsScreen} />
            <Stack.Screen name="Settings" component={SettingsScreen} />
          </>
        ) : (
          <Stack.Screen name="Login" component={LoginScreen} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  placeholderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f7fa',
    padding: 20,
  },
  placeholderText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 10,
  },
  placeholderSubtext: {
    fontSize: 16,
    color: '#7f8c8d',
    textAlign: 'center',
  },
});

export default AppNavigator;
