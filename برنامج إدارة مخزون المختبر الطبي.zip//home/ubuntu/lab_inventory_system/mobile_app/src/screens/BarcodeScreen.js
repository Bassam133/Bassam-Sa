import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { TextInput, Button, ActivityIndicator, Chip } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { getInventoryByBarcode } from '../services/database';

const BarcodeScreen = ({ navigation }) => {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [scannedData, setScannedData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [manualBarcode, setManualBarcode] = useState('');
  
  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);
  
  const handleBarCodeScanned = async ({ type, data }) => {
    setScanning(false);
    setScannedData({ type, data });
    await searchBarcode(data);
  };
  
  const searchBarcode = async (barcode) => {
    try {
      setLoading(true);
      const items = await getInventoryByBarcode(barcode);
      setInventoryItems(items);
      
      if (items.length === 0) {
        Alert.alert(
          'لم يتم العثور على منتج',
          `لم يتم العثور على منتج برقم تشغيلة: ${barcode}`,
          [{ text: 'حسناً' }]
        );
      }
    } catch (error) {
      console.error('Error searching barcode:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء البحث عن الباركود');
    } finally {
      setLoading(false);
    }
  };
  
  const handleManualSearch = () => {
    if (manualBarcode.trim()) {
      searchBarcode(manualBarcode.trim());
    } else {
      Alert.alert('خطأ', 'الرجاء إدخال رقم الباركود');
    }
  };
  
  const renderPermissionDenied = () => (
    <View style={styles.centeredContainer}>
      <Ionicons name="alert-circle" size={64} color="#e74c3c" />
      <Text style={styles.permissionText}>
        يرجى السماح للتطبيق بالوصول إلى الكاميرا لاستخدام ميزة مسح الباركود
      </Text>
      <Button 
        mode="contained" 
        onPress={async () => {
          const { status } = await BarCodeScanner.requestPermissionsAsync();
          setHasPermission(status === 'granted');
        }}
        style={styles.button}
      >
        طلب الإذن مرة أخرى
      </Button>
    </View>
  );
  
  const renderScanner = () => (
    <View style={styles.scannerContainer}>
      <BarCodeScanner
        onBarCodeScanned={handleBarCodeScanned}
        style={styles.scanner}
      />
      <View style={styles.scannerOverlay}>
        <View style={styles.scannerTargetCorner1} />
        <View style={styles.scannerTargetCorner2} />
        <View style={styles.scannerTargetCorner3} />
        <View style={styles.scannerTargetCorner4} />
      </View>
      <Button 
        mode="contained" 
        onPress={() => setScanning(false)}
        style={styles.cancelButton}
      >
        إلغاء
      </Button>
    </View>
  );
  
  const renderInventoryItem = (item, index) => (
    <View key={item.id} style={styles.resultCard}>
      <View style={styles.resultHeader}>
        <Text style={styles.resultTitle}>{item.product_name}</Text>
        <Chip mode="outlined" style={styles.lotChip}>
          رقم التشغيلة: {item.lot_number}
        </Chip>
      </View>
      
      <View style={styles.resultDetails}>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>تاريخ الإنتاج:</Text>
          <Text style={styles.detailValue}>{item.production_date}</Text>
        </View>
        
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>تاريخ الانتهاء:</Text>
          <Text style={[
            styles.detailValue, 
            new Date(item.expiry_date) < new Date() ? styles.expired : {}
          ]}>
            {item.expiry_date}
          </Text>
        </View>
        
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>الكمية المتوفرة:</Text>
          <Text style={styles.detailValue}>{item.quantity}</Text>
        </View>
        
        {item.location && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>الموقع:</Text>
            <Text style={styles.detailValue}>{item.location}</Text>
          </View>
        )}
      </View>
      
      <View style={styles.resultActions}>
        <Button 
          mode="outlined" 
          onPress={() => navigation.navigate('InventoryTab', {
            screen: 'InventoryDetail',
            params: { id: item.id }
          })}
          style={styles.actionButton}
        >
          التفاصيل
        </Button>
      </View>
    </View>
  );
  
  return (
    <View style={styles.container}>
      {scanning ? (
        hasPermission === null ? (
          <View style={styles.centeredContainer}>
            <ActivityIndicator size="large" color="#3498db" />
            <Text style={styles.loadingText}>جاري التحقق من إذن الكاميرا...</Text>
          </View>
        ) : hasPermission === false ? (
          renderPermissionDenied()
        ) : (
          renderScanner()
        )
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Ionicons name="barcode" size={64} color="#3498db" />
            <Text style={styles.title}>قراءة الباركود</Text>
            <Text style={styles.subtitle}>
              قم بمسح الباركود للبحث عن المنتج في المخزون
            </Text>
          </View>
          
          <View style={styles.manualInputContainer}>
            <TextInput
              label="إدخال رقم الباركود يدوياً"
              value={manualBarcode}
              onChangeText={setManualBarcode}
              style={styles.input}
              mode="outlined"
              right={<TextInput.Icon icon="barcode" />}
            />
            <Button 
              mode="contained" 
              onPress={handleManualSearch}
              style={styles.button}
              disabled={loading}
            >
              بحث
            </Button>
          </View>
          
          <Button 
            mode="contained" 
            onPress={() => setScanning(true)}
            style={[styles.button, styles.scanButton]}
            icon="camera"
          >
            مسح الباركود
          </Button>
          
          {scannedData && (
            <View style={styles.scannedDataContainer}>
              <Text style={styles.scannedDataTitle}>آخر باركود تم مسحه:</Text>
              <Text style={styles.scannedDataValue}>{scannedData.data}</Text>
              <Text style={styles.scannedDataType}>
                نوع الباركود: {scannedData.type}
              </Text>
            </View>
          )}
          
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#3498db" />
              <Text style={styles.loadingText}>جاري البحث...</Text>
            </View>
          ) : inventoryItems.length > 0 ? (
            <View style={styles.resultsContainer}>
              <Text style={styles.resultsTitle}>نتائج البحث:</Text>
              {inventoryItems.map(renderInventoryItem)}
            </View>
          ) : null}
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginTop: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#7f8c8d',
    textAlign: 'center',
    marginTop: 5,
  },
  manualInputContainer: {
    marginBottom: 20,
  },
  input: {
    marginBottom: 10,
  },
  button: {
    marginVertical: 10,
  },
  scanButton: {
    backgroundColor: '#3498db',
  },
  centeredContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  permissionText: {
    textAlign: 'center',
    marginVertical: 20,
    color: '#7f8c8d',
    fontSize: 16,
  },
  loadingText: {
    marginTop: 10,
    color: '#7f8c8d',
  },
  scannerContainer: {
    flex: 1,
    position: 'relative',
  },
  scanner: {
    ...StyleSheet.absoluteFillObject,
  },
  scannerOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scannerTargetCorner1: {
    position: 'absolute',
    top: '35%',
    left: '25%',
    width: 20,
    height: 20,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderColor: '#3498db',
  },
  scannerTargetCorner2: {
    position: 'absolute',
    top: '35%',
    right: '25%',
    width: 20,
    height: 20,
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderColor: '#3498db',
  },
  scannerTargetCorner3: {
    position: 'absolute',
    bottom: '35%',
    left: '25%',
    width: 20,
    height: 20,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderColor: '#3498db',
  },
  scannerTargetCorner4: {
    position: 'absolute',
    bottom: '35%',
    right: '25%',
    width: 20,
    height: 20,
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderColor: '#3498db',
  },
  cancelButton: {
    position: 'absolute',
    bottom: 30,
    alignSelf: 'center',
    backgroundColor: '#e74c3c',
  },
  scannedDataContainer: {
    backgroundColor: '#ecf0f1',
    padding: 15,
    borderRadius: 10,
    marginVertical: 20,
  },
  scannedDataTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 5,
  },
  scannedDataValue: {
    fontSize: 18,
    color: '#3498db',
    marginBottom: 5,
  },
  scannedDataType: {
    fontSize: 14,
    color: '#7f8c8d',
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  resultsContainer: {
    marginTop: 20,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 10,
  },
  resultCard: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    flexWrap: 'wrap',
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    flex: 1,
  },
  lotChip: {
    marginLeft: 10,
  },
  resultDetails: {
    marginBottom: 15,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  detailLabel: {
    fontSize: 14,
    color: '#7f8c8d',
    width: '40%',
  },
  detailValue: {
    fontSize: 14,
    color: '#2c3e50',
    fontWeight: 'bold',
  },
  expired: {
    color: '#e74c3c',
  },
  resultActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  actionButton: {
    marginLeft: 10,
  },
});

export default BarcodeScreen;
