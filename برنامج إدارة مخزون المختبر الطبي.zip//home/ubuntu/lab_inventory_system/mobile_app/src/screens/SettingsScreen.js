import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { TextInput, Button, Switch, Divider, List } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';

const SettingsScreen = ({ navigation }) => {
  const [expiryThreshold, setExpiryThreshold] = useState('30');
  const [enablePushNotifications, setEnablePushNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [saving, setSaving] = useState(false);
  
  const user = useSelector(state => state.auth.user);
  const dispatch = useDispatch();
  
  const handleSaveSettings = () => {
    setSaving(true);
    
    // Validate expiry threshold
    const threshold = parseInt(expiryThreshold);
    if (isNaN(threshold) || threshold < 1 || threshold > 365) {
      Alert.alert('خطأ', 'يرجى إدخال عدد أيام صحيح بين 1 و 365');
      setSaving(false);
      return;
    }
    
    // In a real app, this would save to the database and update Redux
    setTimeout(() => {
      dispatch({
        type: 'UPDATE_NOTIFICATION_SETTINGS',
        payload: {
          expiryThreshold: threshold,
          enablePushNotifications
        }
      });
      
      Alert.alert('تم', 'تم حفظ الإعدادات بنجاح');
      setSaving(false);
    }, 1000);
  };
  
  const handleLogout = () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من رغبتك في تسجيل الخروج؟',
      [
        {
          text: 'إلغاء',
          style: 'cancel'
        },
        {
          text: 'تسجيل الخروج',
          onPress: () => {
            dispatch({ type: 'LOGOUT' });
          },
          style: 'destructive'
        }
      ]
    );
  };
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="settings" size={32} color="#3498db" />
        <Text style={styles.headerTitle}>الإعدادات</Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>إعدادات التنبيهات</Text>
        
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>
            عدد أيام التنبيه قبل انتهاء الصلاحية:
          </Text>
          <TextInput
            value={expiryThreshold}
            onChangeText={setExpiryThreshold}
            keyboardType="number-pad"
            style={styles.thresholdInput}
            mode="outlined"
          />
        </View>
        
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>تفعيل إشعارات الجوال:</Text>
          <Switch
            value={enablePushNotifications}
            onValueChange={setEnablePushNotifications}
            color="#3498db"
          />
        </View>
      </View>
      
      <Divider style={styles.divider} />
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>إعدادات التطبيق</Text>
        
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>الوضع الداكن:</Text>
          <Switch
            value={darkMode}
            onValueChange={setDarkMode}
            color="#3498db"
          />
        </View>
      </View>
      
      <Divider style={styles.divider} />
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>معلومات الحساب</Text>
        
        <List.Item
          title="اسم المستخدم"
          description={user?.username || 'غير متوفر'}
          left={props => <List.Icon {...props} icon="account" />}
        />
        
        <List.Item
          title="الاسم"
          description={user?.name || 'غير متوفر'}
          left={props => <List.Icon {...props} icon="card-account-details" />}
        />
        
        <List.Item
          title="الدور"
          description={user?.role === 'admin' ? 'مدير النظام' : 'مستخدم'}
          left={props => <List.Icon {...props} icon="shield-account" />}
        />
      </View>
      
      <View style={styles.buttonContainer}>
        <Button
          mode="contained"
          onPress={handleSaveSettings}
          style={styles.saveButton}
          loading={saving}
          disabled={saving}
        >
          حفظ الإعدادات
        </Button>
        
        <Button
          mode="outlined"
          onPress={handleLogout}
          style={styles.logoutButton}
          color="#e74c3c"
        >
          تسجيل الخروج
        </Button>
      </View>
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          نظام إدارة مخزون المختبر الطبي - الإصدار 1.0.0
        </Text>
        <Text style={styles.footerText}>
          © 2025 تجمع القصيم الصحي. جميع الحقوق محفوظة.
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'white',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginLeft: 10,
  },
  section: {
    backgroundColor: 'white',
    padding: 15,
    marginTop: 15,
    borderRadius: 10,
    marginHorizontal: 10,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 15,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  settingLabel: {
    fontSize: 16,
    color: '#2c3e50',
    flex: 1,
  },
  thresholdInput: {
    width: 80,
    height: 40,
    textAlign: 'center',
  },
  divider: {
    marginVertical: 10,
  },
  buttonContainer: {
    padding: 15,
    marginTop: 10,
  },
  saveButton: {
    marginBottom: 10,
    backgroundColor: '#3498db',
  },
  logoutButton: {
    borderColor: '#e74c3c',
  },
  footer: {
    padding: 15,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  footerText: {
    color: '#7f8c8d',
    textAlign: 'center',
    marginBottom: 5,
  },
});

export default SettingsScreen;
