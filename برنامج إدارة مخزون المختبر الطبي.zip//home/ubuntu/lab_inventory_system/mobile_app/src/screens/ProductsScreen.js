import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, FAB, Searchbar, ActivityIndicator, Chip } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { getProducts } from '../services/database';

const ProductsScreen = ({ navigation }) => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [categories, setCategories] = useState([]);
  
  useEffect(() => {
    loadProducts();
  }, []);
  
  const loadProducts = async () => {
    try {
      setLoading(true);
      const productsData = await getProducts();
      setProducts(productsData);
      setFilteredProducts(productsData);
      
      // Extract unique categories
      const uniqueCategories = [...new Set(productsData.map(p => p.category_name).filter(Boolean))];
      setCategories(uniqueCategories);
    } catch (error) {
      console.error('Error loading products:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل المنتجات');
    } finally {
      setLoading(false);
    }
  };
  
  const handleSearch = (query) => {
    setSearchQuery(query);
    filterProducts(query, selectedCategory);
  };
  
  const handleCategorySelect = (category) => {
    if (selectedCategory === category) {
      setSelectedCategory(null);
      filterProducts(searchQuery, null);
    } else {
      setSelectedCategory(category);
      filterProducts(searchQuery, category);
    }
  };
  
  const filterProducts = (query, category) => {
    let filtered = products;
    
    if (query) {
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(query.toLowerCase()) ||
        (product.description && product.description.toLowerCase().includes(query.toLowerCase()))
      );
    }
    
    if (category) {
      filtered = filtered.filter(product => product.category_name === category);
    }
    
    setFilteredProducts(filtered);
  };
  
  const renderProductItem = ({ item }) => (
    <Card 
      style={styles.card}
      onPress={() => navigation.navigate('ProductDetail', { id: item.id })}
    >
      <Card.Content>
        <Title>{item.name}</Title>
        {item.category_name && (
          <Chip style={styles.chip} mode="outlined">{item.category_name}</Chip>
        )}
        {item.description && (
          <Paragraph numberOfLines={2}>{item.description}</Paragraph>
        )}
        {item.manufacturer_name && (
          <Paragraph style={styles.manufacturer}>
            الشركة المصنعة: {item.manufacturer_name}
          </Paragraph>
        )}
      </Card.Content>
    </Card>
  );
  
  const renderCategoryChip = (category) => (
    <Chip
      key={category}
      style={[
        styles.categoryChip,
        selectedCategory === category && styles.selectedCategoryChip
      ]}
      textStyle={selectedCategory === category ? styles.selectedCategoryText : {}}
      onPress={() => handleCategorySelect(category)}
      mode={selectedCategory === category ? "flat" : "outlined"}
    >
      {category}
    </Chip>
  );
  
  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="البحث عن منتج..."
        onChangeText={handleSearch}
        value={searchQuery}
        style={styles.searchbar}
        iconColor="#3498db"
      />
      
      {categories.length > 0 && (
        <FlatList
          data={categories}
          renderItem={({ item }) => renderCategoryChip(item)}
          keyExtractor={item => item}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        />
      )}
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.loadingText}>جاري تحميل المنتجات...</Text>
        </View>
      ) : filteredProducts.length > 0 ? (
        <FlatList
          data={filteredProducts}
          renderItem={renderProductItem}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContainer}
          refreshing={loading}
          onRefresh={loadProducts}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="search" size={64} color="#7f8c8d" />
          <Text style={styles.emptyText}>لا توجد منتجات مطابقة للبحث</Text>
          <Button 
            mode="outlined" 
            onPress={loadProducts}
            style={styles.refreshButton}
          >
            تحديث
          </Button>
        </View>
      )}
      
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => navigation.navigate('AddProduct')}
        color="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  searchbar: {
    margin: 10,
    elevation: 2,
  },
  categoriesContainer: {
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  categoryChip: {
    marginHorizontal: 5,
    backgroundColor: 'white',
  },
  selectedCategoryChip: {
    backgroundColor: '#3498db',
  },
  selectedCategoryText: {
    color: 'white',
  },
  listContainer: {
    padding: 10,
  },
  card: {
    marginBottom: 10,
    elevation: 2,
  },
  chip: {
    alignSelf: 'flex-start',
    marginVertical: 5,
  },
  manufacturer: {
    marginTop: 5,
    fontSize: 12,
    color: '#7f8c8d',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#7f8c8d',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 10,
    marginBottom: 20,
    fontSize: 16,
    color: '#7f8c8d',
    textAlign: 'center',
  },
  refreshButton: {
    marginTop: 10,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    left: 0,
    bottom: 0,
    backgroundColor: '#3498db',
  },
});

export default ProductsScreen;
