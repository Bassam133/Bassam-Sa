import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, DataTable } from 'react-native-paper';
import { useSelector } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { getInventory, getExpiringInventory } from '../services/database';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Print from 'expo-print';
import { shareAsync } from 'expo-sharing';

const ReportsScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [inventory, setInventory] = useState([]);
  const [expiringItems, setExpiringItems] = useState([]);
  const [expiredItems, setExpiredItems] = useState([]);
  const [generatingReport, setGeneratingReport] = useState(false);
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    try {
      setLoading(true);
      
      // Get all inventory
      const inventoryData = await getInventory();
      setInventory(inventoryData);
      
      // Filter expired items
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const expired = inventoryData.filter(item => {
        const expiryDate = new Date(item.expiry_date);
        return expiryDate <= today;
      });
      setExpiredItems(expired);
      
      // Get items expiring in the next 30 days
      const expiring = await getExpiringInventory(30);
      setExpiringItems(expiring);
      
    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };
  
  const generatePDFReport = async (data, reportTitle) => {
    try {
      setGeneratingReport(true);
      
      // Create HTML content for PDF
      let tableRows = '';
      data.forEach(item => {
        tableRows += `
          <tr>
            <td>${item.product_name}</td>
            <td>${item.lot_number}</td>
            <td>${item.production_date}</td>
            <td>${item.expiry_date}</td>
            <td>${item.quantity}</td>
            <td>${item.location || ''}</td>
          </tr>
        `;
      });
      
      const htmlContent = `
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${reportTitle}</title>
          <style>
            body {
              font-family: 'Arial', sans-serif;
              padding: 20px;
              direction: rtl;
            }
            .header {
              text-align: center;
              margin-bottom: 20px;
            }
            .logo {
              max-width: 200px;
              margin-bottom: 10px;
            }
            h1 {
              color: #2c3e50;
              font-size: 24px;
              margin-bottom: 5px;
            }
            .date {
              color: #7f8c8d;
              font-size: 14px;
              margin-bottom: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 8px;
              text-align: right;
            }
            th {
              background-color: #3498db;
              color: white;
            }
            tr:nth-child(even) {
              background-color: #f2f2f2;
            }
            .footer {
              text-align: center;
              font-size: 12px;
              color: #7f8c8d;
              margin-top: 30px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <img src="https://kzovjcfh.manus.space/images/logo.jpeg" class="logo" alt="تجمع القصيم الصحي">
            <h1>نظام إدارة مخزون المختبر الطبي</h1>
            <h2>${reportTitle}</h2>
            <div class="date">تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}</div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>اسم المنتج</th>
                <th>رقم التشغيلة</th>
                <th>تاريخ الإنتاج</th>
                <th>تاريخ الانتهاء</th>
                <th>الكمية</th>
                <th>الموقع</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
          </table>
          
          <div class="footer">
            <p>© ${new Date().getFullYear()} تجمع القصيم الصحي. جميع الحقوق محفوظة.</p>
          </div>
        </body>
        </html>
      `;
      
      // Generate PDF file
      const { uri } = await Print.printToFileAsync({ html: htmlContent });
      
      // Get the PDF file name
      const fileName = `${reportTitle.replace(/ /g, '_')}_${Date.now()}.pdf`;
      
      // Share the PDF file
      await shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf', dialogTitle: `مشاركة تقرير ${reportTitle}` });
      
    } catch (error) {
      console.error('Error generating PDF report:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إنشاء تقرير PDF');
    } finally {
      setGeneratingReport(false);
    }
  };
  
  const generateCSVReport = async (data, filename) => {
    try {
      setGeneratingReport(true);
      
      // Create CSV header
      let csvContent = "اسم المنتج,رقم التشغيلة,تاريخ الإنتاج,تاريخ الانتهاء,الكمية المتوفرة,الموقع\n";
      
      // Add data rows
      data.forEach(item => {
        const row = [
          item.product_name,
          item.lot_number,
          item.production_date,
          item.expiry_date,
          item.quantity,
          item.location || ''
        ].join(',');
        
        csvContent += row + "\n";
      });
      
      // Save to file
      const fileUri = `${FileSystem.documentDirectory}${filename}.csv`;
      await FileSystem.writeAsStringAsync(fileUri, csvContent);
      
      // Share file
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri);
      } else {
        Alert.alert('خطأ', 'مشاركة الملفات غير متاحة على هذا الجهاز');
      }
    } catch (error) {
      console.error('Error generating report:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إنشاء التقرير');
    } finally {
      setGeneratingReport(false);
    }
  };
  
  const printPDF = async (data, reportTitle) => {
    try {
      setGeneratingReport(true);
      
      // Create HTML content for PDF (same as generatePDFReport)
      let tableRows = '';
      data.forEach(item => {
        tableRows += `
          <tr>
            <td>${item.product_name}</td>
            <td>${item.lot_number}</td>
            <td>${item.production_date}</td>
            <td>${item.expiry_date}</td>
            <td>${item.quantity}</td>
            <td>${item.location || ''}</td>
          </tr>
        `;
      });
      
      const htmlContent = `
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${reportTitle}</title>
          <style>
            body {
              font-family: 'Arial', sans-serif;
              padding: 20px;
              direction: rtl;
            }
            .header {
              text-align: center;
              margin-bottom: 20px;
            }
            .logo {
              max-width: 200px;
              margin-bottom: 10px;
            }
            h1 {
              color: #2c3e50;
              font-size: 24px;
              margin-bottom: 5px;
            }
            .date {
              color: #7f8c8d;
              font-size: 14px;
              margin-bottom: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 20px;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 8px;
              text-align: right;
            }
            th {
              background-color: #3498db;
              color: white;
            }
            tr:nth-child(even) {
              background-color: #f2f2f2;
            }
            .footer {
              text-align: center;
              font-size: 12px;
              color: #7f8c8d;
              margin-top: 30px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <img src="https://kzovjcfh.manus.space/images/logo.jpeg" class="logo" alt="تجمع القصيم الصحي">
            <h1>نظام إدارة مخزون المختبر الطبي</h1>
            <h2>${reportTitle}</h2>
            <div class="date">تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}</div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>اسم المنتج</th>
                <th>رقم التشغيلة</th>
                <th>تاريخ الإنتاج</th>
                <th>تاريخ الانتهاء</th>
                <th>الكمية</th>
                <th>الموقع</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
          </table>
          
          <div class="footer">
            <p>© ${new Date().getFullYear()} تجمع القصيم الصحي. جميع الحقوق محفوظة.</p>
          </div>
        </body>
        </html>
      `;
      
      // Print the PDF
      await Print.printAsync({
        html: htmlContent,
      });
      
    } catch (error) {
      console.error('Error printing PDF:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء طباعة التقرير');
    } finally {
      setGeneratingReport(false);
    }
  };
  
  const renderSummaryCard = () => (
    <Card style={styles.card}>
      <Card.Content>
        <Title>ملخص المخزون</Title>
        <View style={styles.summaryContainer}>
          <View style={styles.summaryItem}>
            <Ionicons name="cube" size={32} color="#3498db" />
            <Text style={styles.summaryValue}>{inventory.length}</Text>
            <Text style={styles.summaryLabel}>إجمالي المخزون</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Ionicons name="alert-circle" size={32} color="#f39c12" />
            <Text style={styles.summaryValue}>{expiringItems.length}</Text>
            <Text style={styles.summaryLabel}>ينتهي قريباً</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Ionicons name="close-circle" size={32} color="#e74c3c" />
            <Text style={styles.summaryValue}>{expiredItems.length}</Text>
            <Text style={styles.summaryLabel}>منتهي الصلاحية</Text>
          </View>
        </View>
      </Card.Content>
      <Card.Actions style={styles.cardActions}>
        <Button 
          mode="contained" 
          onPress={() => generatePDFReport(inventory, 'تقرير المخزون الكامل')}
          loading={generatingReport}
          disabled={generatingReport || inventory.length === 0}
          style={styles.pdfButton}
          icon="file-pdf-box"
        >
          تصدير PDF
        </Button>
        <Button 
          mode="outlined" 
          onPress={() => printPDF(inventory, 'تقرير المخزون الكامل')}
          loading={generatingReport}
          disabled={generatingReport || inventory.length === 0}
          style={styles.printButton}
          icon="printer"
        >
          طباعة
        </Button>
      </Card.Actions>
    </Card>
  );
  
  const renderExpiringItemsCard = () => (
    <Card style={styles.card}>
      <Card.Content>
        <Title>المنتجات قريبة الانتهاء</Title>
        {expiringItems.length > 0 ? (
          <DataTable>
            <DataTable.Header>
              <DataTable.Title>المنتج</DataTable.Title>
              <DataTable.Title>رقم التشغيلة</DataTable.Title>
              <DataTable.Title>تاريخ الانتهاء</DataTable.Title>
              <DataTable.Title numeric>الكمية</DataTable.Title>
            </DataTable.Header>
            
            {expiringItems.slice(0, 5).map(item => (
              <DataTable.Row key={item.id}>
                <DataTable.Cell>{item.product_name}</DataTable.Cell>
                <DataTable.Cell>{item.lot_number}</DataTable.Cell>
                <DataTable.Cell>{item.expiry_date}</DataTable.Cell>
                <DataTable.Cell numeric>{item.quantity}</DataTable.Cell>
              </DataTable.Row>
            ))}
            
            {expiringItems.length > 5 && (
              <View style={styles.moreItemsContainer}>
                <Text style={styles.moreItemsText}>
                  +{expiringItems.length - 5} عناصر أخرى
                </Text>
              </View>
            )}
          </DataTable>
        ) : (
          <Paragraph style={styles.emptyText}>
            لا توجد منتجات قريبة الانتهاء
          </Paragraph>
        )}
      </Card.Content>
      <Card.Actions style={styles.cardActions}>
        <Button 
          mode="contained" 
          onPress={() => generatePDFReport(expiringItems, 'تقرير المنتجات قريبة الانتهاء')}
          loading={generatingReport}
          disabled={generatingReport || expiringItems.length === 0}
          style={styles.pdfButton}
          icon="file-pdf-box"
        >
          تصدير PDF
        </Button>
        <Button 
          mode="outlined" 
          onPress={() => printPDF(expiringItems, 'تقرير المنتجات قريبة الانتهاء')}
          loading={generatingReport}
          disabled={generatingReport || expiringItems.length === 0}
          style={styles.printButton}
          icon="printer"
        >
          طباعة
        </Button>
      </Card.Actions>
    </Card>
  );
  
  const renderExpiredItemsCard = () => (
    <Card style={styles.card}>
      <Card.Content>
        <Title>المنتجات منتهية الصلاحية</Title>
        {expiredItems.length > 0 ? (
          <DataTable>
            <DataTable.Header>
              <DataTable.Title>المنتج</DataTable.Title>
              <DataTable.Title>رقم التشغيلة</DataTable.Title>
              <DataTable.Title>تاريخ الانتهاء</DataTable.Title>
              <DataTable.Title numeric>الكمية</DataTable.Title>
            </DataTable.Header>
            
            {expiredItems.slice(0, 5).map(item => (
              <DataTable.Row key={item.id}>
                <DataTable.Cell>{item.product_name}</DataTable.Cell>
                <DataTable.Cell>{item.lot_number}</DataTable.Cell>
                <DataTable.Cell>{item.expiry_date}</DataTable.Cell>
                <DataTable.Cell numeric>{item.quantity}</DataTable.Cell>
              </DataTable.Row>
            ))}
            
            {expiredItems.length > 5 && (
              <View style={styles.moreItemsContainer}>
                <Text style={styles.moreItemsText}>
                  +{expiredItems.length - 5} عناصر أخرى
                </Text>
              </View>
            )}
          </DataTable>
        ) : (
          <Paragraph style={styles.emptyText}>
            لا توجد منتجات منتهية الصلاحية
          </Paragraph>
        )}
      </Card.Content>
      <Card.Actions style={styles.cardActions}>
        <Button 
          mode="contained" 
          onPress={() => generatePDFReport(expiredItems, 'تقرير المنتجات منتهية الصلاحية')}
          loading={generatingReport}
          disabled={generatingReport || expiredItems.length === 0}
          style={styles.pdfButton}
          icon="file-pdf-box"
        >
          تصدير PDF
        </Button>
        <Button 
          mode="outlined" 
          onPress={() => printPDF(expiredItems, 'تقرير المنتجات منتهية الصلاحية')}
          loading={generatingReport}
          disabled={generatingReport || expiredItems.length === 0}
          style={styles.printButton}
          icon="printer"
        >
          طباعة
        </Button>
      </Card.Actions>
    </Card>
 <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>