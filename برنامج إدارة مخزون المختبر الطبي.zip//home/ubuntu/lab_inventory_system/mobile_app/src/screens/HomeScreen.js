import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, FAB } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { getExpiringInventory } from '../services/database';

const HomeScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [expiringItems, setExpiringItems] = useState([]);
  const user = useSelector(state => state.auth.user);
  const notificationsCount = useSelector(state => 
    state.notifications.notifications.filter(n => !n.read).length
  );
  
  useEffect(() => {
    loadExpiringItems();
  }, []);
  
  const loadExpiringItems = async () => {
    try {
      setLoading(true);
      // Get items expiring in the next 30 days
      const items = await getExpiringInventory(30);
      setExpiringItems(items);
    } catch (error) {
      console.error('Error loading expiring items:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const onRefresh = async () => {
    setRefreshing(true);
    await loadExpiringItems();
    setRefreshing(false);
  };
  
  const renderExpiringItem = ({ item }) => (
    <Card style={styles.card} onPress={() => navigation.navigate('InventoryTab', {
      screen: 'InventoryDetail',
      params: { id: item.id }
    })}>
      <Card.Content>
        <Title>{item.product_name}</Title>
        <Paragraph>رقم التشغيلة: {item.lot_number}</Paragraph>
        <Paragraph>تاريخ الانتهاء: {item.expiry_date}</Paragraph>
        <Paragraph>الكمية المتبقية: {item.quantity}</Paragraph>
      </Card.Content>
    </Card>
  );
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image 
          source={require('../../assets/logo.jpeg')} 
          style={styles.logo} 
          resizeMode="contain"
        />
        <View style={styles.headerTextContainer}>
          <Text style={styles.headerTitle}>نظام إدارة مخزون المختبر الطبي</Text>
          <Text style={styles.headerSubtitle}>مرحباً، {user?.name || 'مستخدم'}</Text>
        </View>
      </View>
      
      <View style={styles.statsContainer}>
        <TouchableOpacity 
          style={styles.statCard}
          onPress={() => navigation.navigate('ProductsTab')}
        >
          <Ionicons name="flask" size={32} color="#3498db" />
          <Text style={styles.statTitle}>المنتجات</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.statCard}
          onPress={() => navigation.navigate('InventoryTab')}
        >
          <Ionicons name="cube" size={32} color="#2ecc71" />
          <Text style={styles.statTitle}>المخزون</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.statCard}
          onPress={() => navigation.navigate('BarcodeTab')}
        >
          <Ionicons name="barcode" size={32} color="#e74c3c" />
          <Text style={styles.statTitle}>الباركود</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.statCard}
          onPress={() => navigation.navigate('SettingsTab', { screen: 'Notifications' })}
        >
          <View style={styles.notificationIconContainer}>
            <Ionicons name="notifications" size={32} color="#f39c12" />
            {notificationsCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{notificationsCount}</Text>
              </View>
            )}
          </View>
          <Text style={styles.statTitle}>التنبيهات</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>المنتجات قريبة الانتهاء</Text>
        <TouchableOpacity onPress={loadExpiringItems}>
          <Ionicons name="refresh" size={24} color="#3498db" />
        </TouchableOpacity>
      </View>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.loadingText}>جاري تحميل البيانات...</Text>
        </View>
      ) : expiringItems.length > 0 ? (
        <FlatList
          data={expiringItems}
          renderItem={renderExpiringItem}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContainer}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="checkmark-circle" size={64} color="#2ecc71" />
          <Text style={styles.emptyText}>لا توجد منتجات قريبة الانتهاء</Text>
        </View>
      )}
      
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => navigation.navigate('InventoryTab', {
          screen: 'AddInventory'
        })}
        color="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
    padding: 15,
    paddingTop: 50,
  },
  logo: {
    width: 60,
    height: 60,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 5,
  },
  headerTextContainer: {
    marginRight: 15,
    flex: 1,
  },
  headerTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    color: '#ecf0f1',
    fontSize: 14,
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    padding: 15,
  },
  statCard: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    justifyContent: 'center',
    width: '48%',
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  statTitle: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  notificationIconContainer: {
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -5,
    left: -5,
    backgroundColor: 'red',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    paddingBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  listContainer: {
    padding: 15,
    paddingTop: 0,
  },
  card: {
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#7f8c8d',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 10,
    fontSize: 16,
    color: '#7f8c8d',
    textAlign: 'center',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    left: 0,
    bottom: 0,
    backgroundColor: '#3498db',
  },
});

export default HomeScreen;
