import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { TextInput, Button, ActivityIndicator } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { addProduct } from '../services/database';

const AddProductScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [manufacturerId, setManufacturerId] = useState('');
  const [loading, setLoading] = useState(false);
  
  const handleSave = async () => {
    // Validate inputs
    if (!name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم المنتج');
      return;
    }
    
    try {
      setLoading(true);
      
      const product = {
        name,
        description,
        category_id: categoryId ? parseInt(categoryId) : null,
        manufacturer_id: manufacturerId ? parseInt(manufacturerId) : null
      };
      
      const productId = await addProduct(product);
      
      Alert.alert(
        'تم',
        'تم إضافة المنتج بنجاح',
        [
          {
            text: 'حسناً',
            onPress: () => navigation.goBack()
          }
        ]
      );
    } catch (error) {
      console.error('Error adding product:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إضافة المنتج');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="add-circle" size={32} color="#3498db" />
        <Text style={styles.headerTitle}>إضافة منتج جديد</Text>
      </View>
      
      <View style={styles.formContainer}>
        <TextInput
          label="اسم المنتج *"
          value={name}
          onChangeText={setName}
          style={styles.input}
          mode="outlined"
        />
        
        <TextInput
          label="الوصف"
          value={description}
          onChangeText={setDescription}
          style={styles.input}
          mode="outlined"
          multiline
          numberOfLines={3}
        />
        
        <TextInput
          label="معرف الفئة"
          value={categoryId}
          onChangeText={setCategoryId}
          style={styles.input}
          mode="outlined"
          keyboardType="number-pad"
        />
        
        <TextInput
          label="معرف الشركة المصنعة"
          value={manufacturerId}
          onChangeText={setManufacturerId}
          style={styles.input}
          mode="outlined"
          keyboardType="number-pad"
        />
        
        <Text style={styles.requiredFieldsNote}>* الحقول المطلوبة</Text>
        
        <View style={styles.buttonContainer}>
          <Button
            mode="contained"
            onPress={handleSave}
            style={styles.saveButton}
            loading={loading}
            disabled={loading}
          >
            حفظ
          </Button>
          
          <Button
            mode="outlined"
            onPress={() => navigation.goBack()}
            style={styles.cancelButton}
          >
            إلغاء
          </Button>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'white',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginLeft: 10,
  },
  formContainer: {
    padding: 15,
  },
  input: {
    marginBottom: 15,
    backgroundColor: 'white',
  },
  requiredFieldsNote: {
    color: '#e74c3c',
    marginBottom: 15,
    fontSize: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  saveButton: {
    flex: 1,
    marginRight: 10,
    backgroundColor: '#3498db',
  },
  cancelButton: {
    flex: 1,
    marginLeft: 10,
  },
});

export default AddProductScreen;
