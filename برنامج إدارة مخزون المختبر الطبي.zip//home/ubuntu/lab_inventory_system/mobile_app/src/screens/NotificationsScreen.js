import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, ActivityIndicator, List, Divider } from 'react-native-paper';
import { useSelector } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { getNotifications, markNotificationAsRead } from '../services/database';

const NotificationsScreen = ({ navigation }) => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadNotifications();
  }, []);
  
  const loadNotifications = async () => {
    try {
      setLoading(true);
      const notificationsData = await getNotifications();
      setNotifications(notificationsData);
    } catch (error) {
      console.error('Error loading notifications:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل التنبيهات');
    } finally {
      setLoading(false);
    }
  };
  
  const handleMarkAsRead = async (id) => {
    try {
      await markNotificationAsRead(id);
      // Update local state
      setNotifications(notifications.map(notification => 
        notification.id === id ? { ...notification, read: 1 } : notification
      ));
    } catch (error) {
      console.error('Error marking notification as read:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحديث حالة التنبيه');
    }
  };
  
  const getNotificationIcon = (type) => {
    switch (type) {
      case 'expiry':
        return 'alert-circle';
      case 'stock':
        return 'cube';
      case 'system':
        return 'information-circle';
      default:
        return 'notifications';
    }
  };
  
  const getNotificationColor = (type) => {
    switch (type) {
      case 'expiry':
        return '#e74c3c';
      case 'stock':
        return '#3498db';
      case 'system':
        return '#2ecc71';
      default:
        return '#f39c12';
    }
  };
  
  const renderNotificationItem = (notification) => (
    <List.Item
      key={notification.id}
      title={notification.title}
      description={notification.message}
      left={props => (
        <View style={[styles.iconContainer, { backgroundColor: getNotificationColor(notification.type) }]}>
          <Ionicons 
            name={getNotificationIcon(notification.type)} 
            size={24} 
            color="white" 
          />
        </View>
      )}
      right={props => (
        notification.read ? (
          <Text style={styles.readText}>تمت القراءة</Text>
        ) : (
          <Button 
            mode="text" 
            onPress={() => handleMarkAsRead(notification.id)}
            style={styles.markReadButton}
          >
            تحديد كمقروء
          </Button>
        )
      )}
      style={[
        styles.notificationItem,
        notification.read ? styles.readNotification : styles.unreadNotification
      ]}
    />
  );
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="notifications" size={32} color="#3498db" />
        <Text style={styles.headerTitle}>التنبيهات</Text>
      </View>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.loadingText}>جاري تحميل التنبيهات...</Text>
        </View>
      ) : notifications.length > 0 ? (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <List.Section>
            {notifications.map((notification, index) => (
              <React.Fragment key={notification.id}>
                {renderNotificationItem(notification)}
                {index < notifications.length - 1 && <Divider />}
              </React.Fragment>
            ))}
          </List.Section>
        </ScrollView>
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="checkmark-circle" size={64} color="#2ecc71" />
          <Text style={styles.emptyText}>لا توجد تنبيهات</Text>
          <Button 
            mode="outlined" 
            onPress={loadNotifications}
            style={styles.refreshButton}
          >
            تحديث
          </Button>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'white',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginLeft: 10,
  },
  scrollContent: {
    padding: 10,
  },
  notificationItem: {
    marginVertical: 5,
    borderRadius: 5,
  },
  unreadNotification: {
    backgroundColor: 'white',
  },
  readNotification: {
    backgroundColor: '#f8f9fa',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    marginVertical: 5,
  },
  markReadButton: {
    marginVertical: 5,
  },
  readText: {
    color: '#7f8c8d',
    fontSize: 12,
    marginVertical: 15,
    marginHorizontal: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#7f8c8d',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 10,
    marginBottom: 20,
    fontSize: 16,
    color: '#7f8c8d',
    textAlign: 'center',
  },
  refreshButton: {
    marginTop: 10,
  },
});

export default NotificationsScreen;
