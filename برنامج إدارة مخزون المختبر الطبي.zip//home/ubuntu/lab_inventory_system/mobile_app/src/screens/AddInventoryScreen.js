import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { TextInput, Button, ActivityIndicator, HelperText } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { addInventoryItem } from '../services/database';
import DateTimePicker from '@react-native-community/datetimepicker';

const AddInventoryScreen = ({ navigation }) => {
  const [productId, setProductId] = useState('');
  const [lotNumber, setLotNumber] = useState('');
  const [productionDate, setProductionDate] = useState(new Date());
  const [expiryDate, setExpiryDate] = useState(new Date());
  const [quantity, setQuantity] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  
  const [showProductionDatePicker, setShowProductionDatePicker] = useState(false);
  const [showExpiryDatePicker, setShowExpiryDatePicker] = useState(false);
  
  const handleSave = async () => {
    // Validate inputs
    if (!productId.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال معرف المنتج');
      return;
    }
    
    if (!lotNumber.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال رقم التشغيلة');
      return;
    }
    
    if (!quantity.trim() || isNaN(parseInt(quantity)) || parseInt(quantity) <= 0) {
      Alert.alert('خطأ', 'يرجى إدخال كمية صحيحة');
      return;
    }
    
    try {
      setLoading(true);
      
      const inventoryItem = {
        product_id: parseInt(productId),
        lot_number: lotNumber,
        production_date: productionDate.toISOString().split('T')[0],
        expiry_date: expiryDate.toISOString().split('T')[0],
        quantity: parseInt(quantity),
        location,
        notes
      };
      
      const itemId = await addInventoryItem(inventoryItem);
      
      Alert.alert(
        'تم',
        'تم إضافة عنصر المخزون بنجاح',
        [
          {
            text: 'حسناً',
            onPress: () => navigation.goBack()
          }
        ]
      );
    } catch (error) {
      console.error('Error adding inventory item:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء إضافة عنصر المخزون');
    } finally {
      setLoading(false);
    }
  };
  
  const onProductionDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || productionDate;
    setShowProductionDatePicker(false);
    setProductionDate(currentDate);
  };
  
  const onExpiryDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || expiryDate;
    setShowExpiryDatePicker(false);
    setExpiryDate(currentDate);
  };
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="add-circle" size={32} color="#3498db" />
        <Text style={styles.headerTitle}>إضافة عنصر مخزون جديد</Text>
      </View>
      
      <View style={styles.formContainer}>
        <TextInput
          label="معرف المنتج *"
          value={productId}
          onChangeText={setProductId}
          style={styles.input}
          mode="outlined"
          keyboardType="number-pad"
        />
        
        <TextInput
          label="رقم التشغيلة (Lot Number) *"
          value={lotNumber}
          onChangeText={setLotNumber}
          style={styles.input}
          mode="outlined"
        />
        
        <View style={styles.dateContainer}>
          <Text style={styles.dateLabel}>تاريخ الإنتاج:</Text>
          <Button 
            mode="outlined" 
            onPress={() => setShowProductionDatePicker(true)}
            style={styles.dateButton}
          >
            {productionDate.toISOString().split('T')[0]}
          </Button>
          
          {showProductionDatePicker && (
            <DateTimePicker
              value={productionDate}
              mode="date"
              display="default"
              onChange={onProductionDateChange}
            />
          )}
        </View>
        
        <View style={styles.dateContainer}>
          <Text style={styles.dateLabel}>تاريخ الانتهاء:</Text>
          <Button 
            mode="outlined" 
            onPress={() => setShowExpiryDatePicker(true)}
            style={styles.dateButton}
          >
            {expiryDate.toISOString().split('T')[0]}
          </Button>
          
          {showExpiryDatePicker && (
            <DateTimePicker
              value={expiryDate}
              mode="date"
              display="default"
              onChange={onExpiryDateChange}
            />
          )}
        </View>
        
        <TextInput
          label="الكمية *"
          value={quantity}
          onChangeText={setQuantity}
          style={styles.input}
          mode="outlined"
          keyboardType="number-pad"
        />
        
        <TextInput
          label="الموقع"
          value={location}
          onChangeText={setLocation}
          style={styles.input}
          mode="outlined"
        />
        
        <TextInput
          label="ملاحظات"
          value={notes}
          onChangeText={setNotes}
          style={styles.input}
          mode="outlined"
          multiline
          numberOfLines={3}
        />
        
        <Text style={styles.requiredFieldsNote}>* الحقول المطلوبة</Text>
        
        <View style={styles.buttonContainer}>
          <Button
            mode="contained"
            onPress={handleSave}
            style={styles.saveButton}
            loading={loading}
            disabled={loading}
          >
            حفظ
          </Button>
          
          <Button
            mode="outlined"
            onPress={() => navigation.goBack()}
            style={styles.cancelButton}
          >
            إلغاء
          </Button>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'white',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginLeft: 10,
  },
  formContainer: {
    padding: 15,
  },
  input: {
    marginBottom: 15,
    backgroundColor: 'white',
  },
  dateContainer: {
    marginBottom: 15,
  },
  dateLabel: {
    fontSize: 16,
    color: '#2c3e50',
    marginBottom: 5,
  },
  dateButton: {
    backgroundColor: 'white',
  },
  requiredFieldsNote: {
    color: '#e74c3c',
    marginBottom: 15,
    fontSize: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  saveButton: {
    flex: 1,
    marginRight: 10,
    backgroundColor: '#3498db',
  },
  cancelButton: {
    flex: 1,
    marginLeft: 10,
  },
});

export default AddInventoryScreen;
