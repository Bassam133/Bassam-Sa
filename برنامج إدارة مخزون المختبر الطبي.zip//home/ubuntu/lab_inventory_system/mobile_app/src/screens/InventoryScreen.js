import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Card, Title, Paragraph, Button, FAB, Searchbar, ActivityIndicator, Chip, Badge } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import { getInventory, getExpiringInventory } from '../services/database';

const InventoryScreen = ({ navigation }) => {
  const [inventory, setInventory] = useState([]);
  const [filteredInventory, setFilteredInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState('all'); // 'all', 'expiring', 'expired'
  
  useEffect(() => {
    loadInventory();
  }, []);
  
  const loadInventory = async () => {
    try {
      setLoading(true);
      const inventoryData = await getInventory();
      setInventory(inventoryData);
      applyFilters(inventoryData, searchQuery, filter);
    } catch (error) {
      console.error('Error loading inventory:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء تحميل بيانات المخزون');
    } finally {
      setLoading(false);
    }
  };
  
  const handleSearch = (query) => {
    setSearchQuery(query);
    applyFilters(inventory, query, filter);
  };
  
  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    applyFilters(inventory, searchQuery, newFilter);
  };
  
  const applyFilters = (data, query, filterType) => {
    let filtered = [...data];
    
    // Apply search query
    if (query) {
      filtered = filtered.filter(item => 
        item.product_name.toLowerCase().includes(query.toLowerCase()) ||
        item.lot_number.toLowerCase().includes(query.toLowerCase())
      );
    }
    
    // Apply filter type
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (filterType === 'expiring') {
      const thirtyDaysLater = new Date();
      thirtyDaysLater.setDate(today.getDate() + 30);
      
      filtered = filtered.filter(item => {
        const expiryDate = new Date(item.expiry_date);
        return expiryDate > today && expiryDate <= thirtyDaysLater;
      });
    } else if (filterType === 'expired') {
      filtered = filtered.filter(item => {
        const expiryDate = new Date(item.expiry_date);
        return expiryDate <= today;
      });
    }
    
    setFilteredInventory(filtered);
  };
  
  const getExpiryStatus = (expiryDateStr) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const thirtyDaysLater = new Date();
    thirtyDaysLater.setDate(today.getDate() + 30);
    
    const expiryDate = new Date(expiryDateStr);
    
    if (expiryDate <= today) {
      return { status: 'expired', color: '#e74c3c' };
    } else if (expiryDate <= thirtyDaysLater) {
      return { status: 'expiring', color: '#f39c12' };
    } else {
      return { status: 'valid', color: '#2ecc71' };
    }
  };
  
  const renderInventoryItem = ({ item }) => {
    const expiryStatus = getExpiryStatus(item.expiry_date);
    
    return (
      <Card 
        style={styles.card}
        onPress={() => navigation.navigate('InventoryDetail', { id: item.id })}
      >
        <Card.Content>
          <View style={styles.cardHeader}>
            <Title>{item.product_name}</Title>
            <Badge 
              style={[styles.expiryBadge, { backgroundColor: expiryStatus.color }]}
            >
              {expiryStatus.status === 'expired' ? 'منتهي' : 
               expiryStatus.status === 'expiring' ? 'ينتهي قريباً' : 'ساري'}
            </Badge>
          </View>
          
          <Chip style={styles.lotChip} mode="outlined">
            رقم التشغيلة: {item.lot_number}
          </Chip>
          
          <View style={styles.dateContainer}>
            <View style={styles.dateItem}>
              <Text style={styles.dateLabel}>تاريخ الإنتاج:</Text>
              <Text style={styles.dateValue}>{item.production_date}</Text>
            </View>
            
            <View style={styles.dateItem}>
              <Text style={styles.dateLabel}>تاريخ الانتهاء:</Text>
              <Text style={[
                styles.dateValue, 
                { color: expiryStatus.color }
              ]}>
                {item.expiry_date}
              </Text>
            </View>
          </View>
          
          <View style={styles.quantityContainer}>
            <Text style={styles.quantityLabel}>الكمية المتوفرة:</Text>
            <Text style={styles.quantityValue}>{item.quantity}</Text>
          </View>
        </Card.Content>
      </Card>
    );
  };
  
  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="البحث في المخزون..."
        onChangeText={handleSearch}
        value={searchQuery}
        style={styles.searchbar}
        iconColor="#3498db"
      />
      
      <View style={styles.filterContainer}>
        <TouchableOpacity
          style={[
            styles.filterButton,
            filter === 'all' && styles.activeFilterButton
          ]}
          onPress={() => handleFilterChange('all')}
        >
          <Text style={[
            styles.filterButtonText,
            filter === 'all' && styles.activeFilterButtonText
          ]}>
            الكل
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.filterButton,
            filter === 'expiring' && styles.activeFilterButton
          ]}
          onPress={() => handleFilterChange('expiring')}
        >
          <Text style={[
            styles.filterButtonText,
            filter === 'expiring' && styles.activeFilterButtonText
          ]}>
            ينتهي قريباً
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.filterButton,
            filter === 'expired' && styles.activeFilterButton
          ]}
          onPress={() => handleFilterChange('expired')}
        >
          <Text style={[
            styles.filterButtonText,
            filter === 'expired' && styles.activeFilterButtonText
          ]}>
            منتهي الصلاحية
          </Text>
        </TouchableOpacity>
      </View>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.loadingText}>جاري تحميل بيانات المخزون...</Text>
        </View>
      ) : filteredInventory.length > 0 ? (
        <FlatList
          data={filteredInventory}
          renderItem={renderInventoryItem}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContainer}
          refreshing={loading}
          onRefresh={loadInventory}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="cube" size={64} color="#7f8c8d" />
          <Text style={styles.emptyText}>
            لا توجد عناصر مخزون مطابقة للبحث أو التصفية
          </Text>
          <Button 
            mode="outlined" 
            onPress={loadInventory}
            style={styles.refreshButton}
          >
            تحديث
          </Button>
        </View>
      )}
      
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => navigation.navigate('AddInventory')}
        color="#fff"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  searchbar: {
    margin: 10,
    elevation: 2,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  filterButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: '#ecf0f1',
    flex: 1,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  activeFilterButton: {
    backgroundColor: '#3498db',
  },
  filterButtonText: {
    color: '#7f8c8d',
    fontWeight: 'bold',
  },
  activeFilterButtonText: {
    color: 'white',
  },
  listContainer: {
    padding: 10,
  },
  card: {
    marginBottom: 10,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  expiryBadge: {
    marginLeft: 5,
  },
  lotChip: {
    alignSelf: 'flex-start',
    marginBottom: 10,
  },
  dateContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  dateItem: {
    flex: 1,
  },
  dateLabel: {
    fontSize: 12,
    color: '#7f8c8d',
  },
  dateValue: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  quantityLabel: {
    fontSize: 14,
    color: '#7f8c8d',
    marginRight: 5,
  },
  quantityValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#7f8c8d',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 10,
    marginBottom: 20,
    fontSize: 16,
    color: '#7f8c8d',
    textAlign: 'center',
  },
  refreshButton: {
    marginTop: 10,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    left: 0,
    bottom: 0,
    backgroundColor: '#3498db',
  },
});

export default InventoryScreen;
