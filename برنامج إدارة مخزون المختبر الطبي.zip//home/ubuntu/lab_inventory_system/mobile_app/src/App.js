import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { I18nManager } from 'react-native';
import AppNavigator from './navigation/AppNavigator';
import { initDatabase } from './services/database';

// Force RTL for Arabic language
I18nManager.forceRTL(true);

// Initialize the database
initDatabase().catch(error => {
  console.error('Database initialization failed:', error);
});

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="light" />
      <AppNavigator />
    </NavigationContainer>
  );
}
