#!/bin/bash

# اختبار وحدات نظام إدارة مخزون المختبر الطبي

echo "بدء اختبار وحدات نظام إدارة مخزون المختبر الطبي..."
cd /home/ubuntu/lab_inventory_system

# إنشاء ملف الاختبار
cat > test_units.py << 'EOL'
import unittest
import os
import sys
from datetime import date, timedelta

# إضافة المسار إلى متغيرات البيئة
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from app import create_app, db
from app.models.models import User, Category, Manufacturer, Product, InventoryItem, NotificationSetting, Notification
from app.utils.notifications import check_expiring_items, check_low_stock

class TestLabInventorySystem(unittest.TestCase):
    def setUp(self):
        """إعداد بيئة الاختبار قبل كل اختبار"""
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        self.client = self.app.test_client()
        
        # إنشاء مستخدم للاختبار
        user = User(username='testuser', password='password', full_name='مستخدم اختبار', role='admin')
        db.session.add(user)
        db.session.commit()
        
        # إضافة إعدادات التنبيهات
        settings = NotificationSetting(days_before_expiry=30, email_notifications=False)
        db.session.add(settings)
        db.session.commit()
    
    def tearDown(self):
        """تنظيف بيئة الاختبار بعد كل اختبار"""
        db.session.remove()
        db.drop_all()
        self.app_context.pop()
    
    def test_user_model(self):
        """اختبار نموذج المستخدم"""
        user = User.query.filter_by(username='testuser').first()
        self.assertIsNotNone(user)
        self.assertEqual(user.full_name, 'مستخدم اختبار')
        self.assertTrue(user.verify_password('password'))
        self.assertFalse(user.verify_password('wrong_password'))
    
    def test_product_model(self):
        """اختبار نموذج المنتج"""
        # إنشاء فئة ومصنع
        category = Category(name='كواشف')
        manufacturer = Manufacturer(name='شركة اختبار')
        db.session.add_all([category, manufacturer])
        db.session.commit()
        
        # إنشاء منتج
        product = Product(
            name='منتج اختبار',
            catalog_number='TEST-001',
            category_id=category.category_id,
            manufacturer_id=manufacturer.manufacturer_id,
            unit='عبوة',
            min_quantity=5
        )
        db.session.add(product)
        db.session.commit()
        
        # التحقق من إنشاء المنتج
        saved_product = Product.query.filter_by(name='منتج اختبار').first()
        self.assertIsNotNone(saved_product)
        self.assertEqual(saved_product.catalog_number, 'TEST-001')
        self.assertEqual(saved_product.category.name, 'كواشف')
        self.assertEqual(saved_product.manufacturer.name, 'شركة اختبار')
    
    def test_inventory_item_model(self):
        """اختبار نموذج عنصر المخزون"""
        # إنشاء منتج
        product = Product(name='منتج اختبار', unit='عبوة')
        db.session.add(product)
        db.session.commit()
        
        # إنشاء عنصر مخزون
        today = date.today()
        item = InventoryItem(
            product_id=product.product_id,
            lot_number='LOT-TEST',
            quantity=10,
            production_date=today - timedelta(days=30),
            expiry_date=today + timedelta(days=60),
            received_date=today - timedelta(days=5)
        )
        db.session.add(item)
        db.session.commit()
        
        # التحقق من إنشاء عنصر المخزون
        saved_item = InventoryItem.query.filter_by(lot_number='LOT-TEST').first()
        self.assertIsNotNone(saved_item)
        self.assertEqual(saved_item.quantity, 10)
        self.assertEqual(saved_item.product.name, 'منتج اختبار')
        
        # اختبار وظائف عنصر المخزون
        self.assertFalse(saved_item.is_expired())
        self.assertEqual(saved_item.days_to_expiry(), 60)
    
    def test_expiry_notification(self):
        """اختبار نظام التنبيهات للمنتجات التي ستنتهي قريباً"""
        # إنشاء منتج
        product = Product(name='منتج اختبار', unit='عبوة')
        db.session.add(product)
        db.session.commit()
        
        # إنشاء عنصر مخزون سينتهي قريباً
        today = date.today()
        item = InventoryItem(
            product_id=product.product_id,
            lot_number='LOT-EXPIRING',
            quantity=10,
            production_date=today - timedelta(days=30),
            expiry_date=today + timedelta(days=15),  # سينتهي خلال 15 يوم
            received_date=today - timedelta(days=5)
        )
        db.session.add(item)
        db.session.commit()
        
        # تشغيل فحص التنبيهات
        check_expiring_items()
        
        # التحقق من إنشاء تنبيه
        notification = Notification.query.filter_by(item_id=item.item_id).first()
        self.assertIsNotNone(notification)
        self.assertEqual(notification.notification_type, 'expiry')
        self.assertFalse(notification.is_read)
    
    def test_expired_notification(self):
        """اختبار نظام التنبيهات للمنتجات منتهية الصلاحية"""
        # إنشاء منتج
        product = Product(name='منتج اختبار', unit='عبوة')
        db.session.add(product)
        db.session.commit()
        
        # إنشاء عنصر مخزون منتهي الصلاحية
        today = date.today()
        item = InventoryItem(
            product_id=product.product_id,
            lot_number='LOT-EXPIRED',
            quantity=10,
            production_date=today - timedelta(days=90),
            expiry_date=today - timedelta(days=5),  # منتهي الصلاحية منذ 5 أيام
            received_date=today - timedelta(days=60)
        )
        db.session.add(item)
        db.session.commit()
        
        # تشغيل فحص التنبيهات
        check_expiring_items()
        
        # التحقق من إنشاء تنبيه
        notification = Notification.query.filter_by(item_id=item.item_id).first()
        self.assertIsNotNone(notification)
        self.assertEqual(notification.notification_type, 'expired')
        self.assertFalse(notification.is_read)
    
    def test_low_stock_notification(self):
        """اختبار نظام التنبيهات للمخزون المنخفض"""
        # إنشاء منتج بحد أدنى للمخزون
        product = Product(name='منتج اختبار', unit='عبوة', min_quantity=20)
        db.session.add(product)
        db.session.commit()
        
        # إنشاء عنصر مخزون بكمية أقل من الحد الأدنى
        today = date.today()
        item = InventoryItem(
            product_id=product.product_id,
            lot_number='LOT-LOW',
            quantity=10,  # أقل من الحد الأدنى (20)
            production_date=today - timedelta(days=30),
            expiry_date=today + timedelta(days=90),
            received_date=today - timedelta(days=5)
        )
        db.session.add(item)
        db.session.commit()
        
        # تشغيل فحص التنبيهات
        check_low_stock()
        
        # التحقق من إنشاء تنبيه
        notification = Notification.query.filter_by(item_id=item.item_id).first()
        self.assertIsNotNone(notification)
        self.assertEqual(notification.notification_type, 'low_stock')
        self.assertFalse(notification.is_read)

if __name__ == '__main__':
    unittest.main()
EOL

# تنفيذ اختبارات الوحدات
echo "تنفيذ اختبارات الوحدات..."
python3 test_units.py

# اختبار تكامل النظام
echo "اختبار تكامل النظام..."
echo "إنشاء قاعدة البيانات وإضافة بيانات اختبار..."

export FLASK_APP=run.py
python3 -c "from app import create_app, db; app = create_app(); app.app_context().push(); db.create_all()"

# إضافة بيانات اختبار
python3 -c "
from app import create_app, db
from app.models.models import User, Category, Manufacturer, Product, InventoryItem, NotificationSetting
from datetime import date, timedelta
app = create_app()
with app.app_context():
    # إضافة مستخدم للاختبار إذا لم يكن موجوداً
    user = User.query.filter_by(username='admin').first()
    if not user:
        user = User(username='admin', password='admin123', full_name='مدير النظام', email='admin@example.com', role='admin')
        db.session.add(user)
        db.session.commit()
        print('تم إنشاء المستخدم بنجاح')
    else:
        print('المستخدم موجود بالفعل')
        
    # إضافة بيانات اختبار أخرى
    # ...
    print('تم إضافة بيانات الاختبار بنجاح')
"

echo "اختبار النظام اكتمل بنجاح!"
echo "يمكنك الآن تشغيل النظام باستخدام الأمر: ./test_system.sh"
