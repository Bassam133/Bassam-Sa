// Add PDF report generation to the web interface
$(document).ready(function() {
  // PDF Report Generation for Inventory Report
  $('#generate-pdf-inventory').click(function() {
    showLoading('جاري إنشاء تقرير PDF...');
    
    $.ajax({
      url: '/api/reports/generate-inventory-report',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ inventory: inventoryData }),
      success: function(response) {
        hideLoading();
        if (response.success) {
          window.open(response.downloadUrl, '_blank');
        } else {
          showError('حدث خطأ أثناء إنشاء التقرير');
        }
      },
      error: function() {
        hideLoading();
        showError('حدث خطأ أثناء إنشاء التقرير');
      }
    });
  });
  
  // PDF Report Generation for Expiring Items
  $('#generate-pdf-expiring').click(function() {
    showLoading('جاري إنشاء تقرير PDF...');
    
    $.ajax({
      url: '/api/reports/generate-expiring-report',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ inventory: expiringItemsData }),
      success: function(response) {
        hideLoading();
        if (response.success) {
          window.open(response.downloadUrl, '_blank');
        } else {
          showError('حدث خطأ أثناء إنشاء التقرير');
        }
      },
      error: function() {
        hideLoading();
        showError('حدث خطأ أثناء إنشاء التقرير');
      }
    });
  });
  
  // PDF Report Generation for Expired Items
  $('#generate-pdf-expired').click(function() {
    showLoading('جاري إنشاء تقرير PDF...');
    
    $.ajax({
      url: '/api/reports/generate-expired-report',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ inventory: expiredItemsData }),
      success: function(response) {
        hideLoading();
        if (response.success) {
          window.open(response.downloadUrl, '_blank');
        } else {
          showError('حدث خطأ أثناء إنشاء التقرير');
        }
      },
      error: function() {
        hideLoading();
        showError('حدث خطأ أثناء إنشاء التقرير');
      }
    });
  });
  
  // Helper functions
  function showLoading(message) {
    $('#loading-message').text(message || 'جاري التحميل...');
    $('#loading-overlay').show();
  }
  
  function hideLoading() {
    $('#loading-overlay').hide();
  }
  
  function showError(message) {
    alert(message);
  }
});
