// JavaScript لنظام إدارة مخزون المختبر الطبي

document.addEventListener('DOMContentLoaded', function() {
    // تبديل الشريط الجانبي
    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
            document.querySelector('.content').classList.toggle('active');
        });
    }

    // إخفاء رسائل التنبيه بعد 5 ثوانٍ
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.style.display = 'none';
            }, 500);
        }, 5000);
    });

    // تفعيل التواريخ
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(input) {
        if (!input.value) {
            const today = new Date().toISOString().split('T')[0];
            input.value = today;
        }
    });

    // تأكيد الحذف
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('هل أنت متأكد من رغبتك في الحذف؟')) {
                e.preventDefault();
            }
        });
    });

    // تحديث الكمية في نموذج المعاملات
    const transactionTypeSelect = document.getElementById('transaction_type');
    const quantityInput = document.getElementById('quantity');
    const itemSelect = document.getElementById('item_id');
    
    if (transactionTypeSelect && quantityInput && itemSelect) {
        itemSelect.addEventListener('change', function() {
            const selectedOption = itemSelect.options[itemSelect.selectedIndex];
            const maxQuantity = selectedOption.getAttribute('data-quantity');
            
            if (maxQuantity) {
                quantityInput.setAttribute('max', maxQuantity);
                
                // تحديث النص التوضيحي
                const quantityHelp = document.getElementById('quantity-help');
                if (quantityHelp) {
                    quantityHelp.textContent = `الكمية المتاحة: ${maxQuantity}`;
                }
            }
        });
        
        transactionTypeSelect.addEventListener('change', function() {
            const transactionType = transactionTypeSelect.value;
            const selectedOption = itemSelect.options[itemSelect.selectedIndex];
            const maxQuantity = selectedOption.getAttribute('data-quantity');
            
            if (transactionType === 'out' && maxQuantity) {
                quantityInput.setAttribute('max', maxQuantity);
                quantityInput.setAttribute('min', '0.01');
            } else {
                quantityInput.removeAttribute('max');
                quantityInput.setAttribute('min', '0.01');
            }
        });
    }

    // تحديث حالة التنبيهات
    const markAsReadButtons = document.querySelectorAll('.mark-as-read');
    markAsReadButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const notificationId = button.getAttribute('data-notification-id');
            
            // إرسال طلب AJAX لتحديث حالة التنبيه
            fetch(`/notifications/mark-as-read/${notificationId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // تحديث واجهة المستخدم
                    const notificationItem = button.closest('.notification-item');
                    notificationItem.classList.remove('unread');
                    button.style.display = 'none';
                    
                    // تحديث عدد التنبيهات
                    const badge = document.querySelector('.notification-badge .badge');
                    if (badge) {
                        let count = parseInt(badge.textContent);
                        count--;
                        badge.textContent = count;
                        
                        if (count <= 0) {
                            badge.style.display = 'none';
                        }
                    }
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    // البحث في الجداول
    const tableSearch = document.getElementById('table-search');
    if (tableSearch) {
        tableSearch.addEventListener('input', function() {
            const searchText = tableSearch.value.toLowerCase();
            const table = document.querySelector('.table');
            const rows = table.querySelectorAll('tbody tr');
            
            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();
                if (text.includes(searchText)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    // فرز الجداول
    const tableHeaders = document.querySelectorAll('.table th[data-sort]');
    tableHeaders.forEach(function(header) {
        header.addEventListener('click', function() {
            const sortKey = header.getAttribute('data-sort');
            const sortDirection = header.getAttribute('data-direction') || 'asc';
            const table = header.closest('table');
            const rows = Array.from(table.querySelectorAll('tbody tr'));
            
            // إعادة تعيين اتجاه الفرز لجميع الرؤوس
            tableHeaders.forEach(h => h.setAttribute('data-direction', ''));
            
            // تعيين اتجاه الفرز للرأس الحالي
            header.setAttribute('data-direction', sortDirection === 'asc' ? 'desc' : 'asc');
            
            // فرز الصفوف
            rows.sort(function(a, b) {
                const aValue = a.querySelector(`td:nth-child(${Array.from(header.parentNode.children).indexOf(header) + 1})`).textContent;
                const bValue = b.querySelector(`td:nth-child(${Array.from(header.parentNode.children).indexOf(header) + 1})`).textContent;
                
                if (sortDirection === 'asc') {
                    return aValue.localeCompare(bValue, 'ar');
                } else {
                    return bValue.localeCompare(aValue, 'ar');
                }
            });
            
            // إعادة ترتيب الصفوف في الجدول
            const tbody = table.querySelector('tbody');
            rows.forEach(function(row) {
                tbody.appendChild(row);
            });
        });
    });
});
