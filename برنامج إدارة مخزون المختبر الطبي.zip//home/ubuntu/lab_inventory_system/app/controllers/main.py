from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models.models import Product, Category, Manufacturer, InventoryItem
from app import db
from datetime import datetime, date

main = Blueprint('main', __name__)

@main.route('/')
@login_required
def index():
    # الحصول على إحصائيات المخزون
    total_products = Product.query.count()
    total_inventory = InventoryItem.query.filter(InventoryItem.quantity > 0).count()
    
    # الحصول على المنتجات التي ستنتهي صلاحيتها قريبًا
    today = date.today()
    expiring_soon = InventoryItem.query.filter(
        InventoryItem.expiry_date <= today.replace(day=today.day + 30),
        InventoryItem.expiry_date >= today,
        InventoryItem.quantity > 0
    ).order_by(InventoryItem.expiry_date).limit(5).all()
    
    # الحصول على المنتجات منتهية الصلاحية
    expired = InventoryItem.query.filter(
        InventoryItem.expiry_date < today,
        InventoryItem.quantity > 0
    ).order_by(InventoryItem.expiry_date.desc()).limit(5).all()
    
    return render_template('main/index.html', 
                          total_products=total_products,
                          total_inventory=total_inventory,
                          expiring_soon=expiring_soon,
                          expired=expired)

@main.route('/dashboard')
@login_required
def dashboard():
    return render_template('main/dashboard.html')

@main.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        # تحديث إعدادات النظام
        pass
    return render_template('main/settings.html')
