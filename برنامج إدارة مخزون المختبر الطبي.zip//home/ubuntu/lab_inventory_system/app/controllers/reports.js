// Add PDF report generation to the web version
const express = require('express');
const router = express.Router();
const PDFReportGenerator = require('../utils/pdf_report_generator');

// Initialize PDF report generator
const pdfReportGenerator = new PDFReportGenerator();

// Use the PDF report generator router
router.use('/reports', pdfReportGenerator.getRouter());

module.exports = router;
