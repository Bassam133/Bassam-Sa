from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.models.models import Product, InventoryItem, Notification, NotificationSetting
from app import db
from datetime import datetime, date, timedelta

reports = Blueprint('reports', __name__)

@reports.route('/reports/inventory')
@login_required
def inventory_report():
    inventory_items = InventoryItem.query.join(Product).all()
    return render_template('reports/inventory_report.html', inventory_items=inventory_items)

@reports.route('/reports/expiry')
@login_required
def expiry_report():
    # الحصول على المنتجات منتهية الصلاحية
    today = date.today()
    expired = InventoryItem.query.filter(
        InventoryItem.expiry_date < today,
        InventoryItem.quantity > 0
    ).join(Product).order_by(InventoryItem.expiry_date.desc()).all()
    
    # الحصول على المنتجات التي ستنتهي صلاحيتها قريبًا
    expiring_soon = InventoryItem.query.filter(
        InventoryItem.expiry_date <= today + timedelta(days=30),
        InventoryItem.expiry_date >= today,
        InventoryItem.quantity > 0
    ).join(Product).order_by(InventoryItem.expiry_date).all()
    
    return render_template('reports/expiry_report.html', 
                          expired=expired,
                          expiring_soon=expiring_soon)

@reports.route('/reports/transactions')
@login_required
def transactions_report():
    from app.models.models import InventoryTransaction, User
    
    # الحصول على معاملات المخزون
    transactions = InventoryTransaction.query.join(
        InventoryItem, InventoryTransaction.item_id == InventoryItem.item_id
    ).join(
        Product, InventoryItem.product_id == Product.product_id
    ).join(
        User, InventoryTransaction.user_id == User.user_id
    ).order_by(InventoryTransaction.transaction_date.desc()).all()
    
    return render_template('reports/transactions_report.html', transactions=transactions)

@reports.route('/reports/export/inventory')
@login_required
def export_inventory():
    # تصدير تقرير المخزون إلى ملف Excel
    import pandas as pd
    from io import BytesIO
    from flask import send_file
    
    inventory_items = InventoryItem.query.join(Product).all()
    
    data = []
    for item in inventory_items:
        data.append({
            'اسم المنتج': item.product.name,
            'رقم التشغيلة': item.lot_number,
            'الكمية': item.quantity,
            'الموقع': item.location,
            'تاريخ الإنتاج': item.production_date,
            'تاريخ الانتهاء': item.expiry_date,
            'تاريخ الاستلام': item.received_date,
            'الأيام المتبقية': item.days_to_expiry()
        })
    
    df = pd.DataFrame(data)
    
    # إنشاء ملف Excel في الذاكرة
    output = BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='المخزون', index=False)
    
    output.seek(0)
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'inventory_report_{date.today().strftime("%Y-%m-%d")}.xlsx'
    )

@reports.route('/reports/export/expiry')
@login_required
def export_expiry():
    # تصدير تقرير الانتهاء إلى ملف Excel
    import pandas as pd
    from io import BytesIO
    from flask import send_file
    
    today = date.today()
    
    # المنتجات منتهية الصلاحية
    expired = InventoryItem.query.filter(
        InventoryItem.expiry_date < today,
        InventoryItem.quantity > 0
    ).join(Product).all()
    
    # المنتجات التي ستنتهي قريبًا
    expiring_soon = InventoryItem.query.filter(
        InventoryItem.expiry_date <= today + timedelta(days=30),
        InventoryItem.expiry_date >= today,
        InventoryItem.quantity > 0
    ).join(Product).all()
    
    expired_data = []
    for item in expired:
        expired_data.append({
            'اسم المنتج': item.product.name,
            'رقم التشغيلة': item.lot_number,
            'الكمية': item.quantity,
            'تاريخ الانتهاء': item.expiry_date,
            'الموقع': item.location
        })
    
    expiring_data = []
    for item in expiring_soon:
        expiring_data.append({
            'اسم المنتج': item.product.name,
            'رقم التشغيلة': item.lot_number,
            'الكمية': item.quantity,
            'تاريخ الانتهاء': item.expiry_date,
            'الأيام المتبقية': item.days_to_expiry(),
            'الموقع': item.location
        })
    
    # إنشاء ملف Excel في الذاكرة
    output = BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        pd.DataFrame(expired_data).to_excel(writer, sheet_name='منتهية الصلاحية', index=False)
        pd.DataFrame(expiring_data).to_excel(writer, sheet_name='تنتهي قريبًا', index=False)
    
    output.seek(0)
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'expiry_report_{date.today().strftime("%Y-%m-%d")}.xlsx'
    )
