from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.models.models import Notification, NotificationSetting
from app import db
from app.utils.notifications import check_expiring_items, check_low_stock, mark_notification_as_read

notifications = Blueprint('notifications', __name__)

@notifications.route('/notifications')
@login_required
def notifications_list():
    """عرض قائمة التنبيهات"""
    all_notifications = Notification.query.order_by(Notification.created_at.desc()).all()
    return render_template('notifications/notifications_list.html', notifications=all_notifications)

@notifications.route('/notifications/mark-as-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_as_read(notification_id):
    """تحديد التنبيه كمقروء"""
    success = mark_notification_as_read(notification_id)
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': success})
    
    if success:
        flash('تم تحديد التنبيه كمقروء', 'success')
    else:
        flash('حدث خطأ أثناء تحديد التنبيه', 'danger')
    
    return redirect(url_for('notifications.notifications_list'))

@notifications.route('/notifications/mark-all-as-read', methods=['POST'])
@login_required
def mark_all_as_read():
    """تحديد جميع التنبيهات كمقروءة"""
    unread_notifications = Notification.query.filter_by(is_read=False).all()
    
    for notification in unread_notifications:
        notification.is_read = True
    
    db.session.commit()
    flash('تم تحديد جميع التنبيهات كمقروءة', 'success')
    return redirect(url_for('notifications.notifications_list'))

@notifications.route('/notifications/check-now', methods=['POST'])
@login_required
def check_notifications_now():
    """فحص التنبيهات يدوياً"""
    check_expiring_items()
    check_low_stock()
    flash('تم فحص التنبيهات بنجاح', 'success')
    return redirect(url_for('notifications.notifications_list'))

@notifications.route('/notifications/settings', methods=['GET', 'POST'])
@login_required
def notification_settings():
    """إعدادات التنبيهات"""
    settings = NotificationSetting.query.first()
    
    if not settings:
        settings = NotificationSetting(days_before_expiry=30, email_notifications=False)
        db.session.add(settings)
        db.session.commit()
    
    if request.method == 'POST':
        days_before_expiry = request.form.get('days_before_expiry', type=int)
        email_notifications = 'email_notifications' in request.form
        
        settings.days_before_expiry = days_before_expiry
        settings.email_notifications = email_notifications
        
        db.session.commit()
        flash('تم تحديث إعدادات التنبيهات بنجاح', 'success')
        return redirect(url_for('notifications.notification_settings'))
    
    return render_template('notifications/settings.html', settings=settings)
