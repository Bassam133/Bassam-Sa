from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.models.models import Product, Category, Manufacturer, InventoryItem, InventoryTransaction
from app import db
from datetime import datetime, date
from sqlalchemy import func

inventory = Blueprint('inventory', __name__)

# إدارة المنتجات
@inventory.route('/products')
@login_required
def products_list():
    products = Product.query.all()
    return render_template('inventory/products_list.html', products=products)

@inventory.route('/products/add', methods=['GET', 'POST'])
@login_required
def add_product():
    categories = Category.query.all()
    manufacturers = Manufacturer.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        catalog_number = request.form.get('catalog_number')
        category_id = request.form.get('category_id')
        manufacturer_id = request.form.get('manufacturer_id')
        unit = request.form.get('unit')
        storage_conditions = request.form.get('storage_conditions')
        min_quantity = request.form.get('min_quantity', 0, type=int)
        notes = request.form.get('notes')
        
        product = Product(
            name=name,
            catalog_number=catalog_number,
            category_id=category_id,
            manufacturer_id=manufacturer_id,
            unit=unit,
            storage_conditions=storage_conditions,
            min_quantity=min_quantity,
            notes=notes
        )
        
        db.session.add(product)
        db.session.commit()
        flash('تمت إضافة المنتج بنجاح', 'success')
        return redirect(url_for('inventory.products_list'))
    
    return render_template('inventory/add_product.html', 
                          categories=categories, 
                          manufacturers=manufacturers)

@inventory.route('/products/edit/<int:product_id>', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    categories = Category.query.all()
    manufacturers = Manufacturer.query.all()
    
    if request.method == 'POST':
        product.name = request.form.get('name')
        product.catalog_number = request.form.get('catalog_number')
        product.category_id = request.form.get('category_id')
        product.manufacturer_id = request.form.get('manufacturer_id')
        product.unit = request.form.get('unit')
        product.storage_conditions = request.form.get('storage_conditions')
        product.min_quantity = request.form.get('min_quantity', 0, type=int)
        product.notes = request.form.get('notes')
        
        db.session.commit()
        flash('تم تحديث المنتج بنجاح', 'success')
        return redirect(url_for('inventory.products_list'))
    
    return render_template('inventory/edit_product.html', 
                          product=product,
                          categories=categories, 
                          manufacturers=manufacturers)

@inventory.route('/products/delete/<int:product_id>', methods=['POST'])
@login_required
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    # التحقق من عدم وجود عناصر مخزون مرتبطة بالمنتج
    if product.inventory_items.count() > 0:
        flash('لا يمكن حذف المنتج لأنه مرتبط بعناصر في المخزون', 'danger')
        return redirect(url_for('inventory.products_list'))
    
    db.session.delete(product)
    db.session.commit()
    flash('تم حذف المنتج بنجاح', 'success')
    return redirect(url_for('inventory.products_list'))

# إدارة المخزون
@inventory.route('/inventory')
@login_required
def inventory_list():
    inventory_items = InventoryItem.query.join(Product).all()
    return render_template('inventory/inventory_list.html', inventory_items=inventory_items)

@inventory.route('/inventory/add', methods=['GET', 'POST'])
@login_required
def add_inventory():
    products = Product.query.all()
    
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        lot_number = request.form.get('lot_number')
        barcode = request.form.get('barcode')
        quantity = request.form.get('quantity', type=float)
        location = request.form.get('location')
        
        # تحويل التواريخ من النص إلى كائنات تاريخ
        production_date_str = request.form.get('production_date')
        expiry_date_str = request.form.get('expiry_date')
        received_date_str = request.form.get('received_date')
        
        production_date = datetime.strptime(production_date_str, '%Y-%m-%d').date() if production_date_str else None
        expiry_date = datetime.strptime(expiry_date_str, '%Y-%m-%d').date()
        received_date = datetime.strptime(received_date_str, '%Y-%m-%d').date()
        
        inventory_item = InventoryItem(
            product_id=product_id,
            lot_number=lot_number,
            barcode=barcode,
            quantity=quantity,
            location=location,
            production_date=production_date,
            expiry_date=expiry_date,
            received_date=received_date
        )
        
        db.session.add(inventory_item)
        db.session.commit()
        
        # إضافة معاملة إدخال للمخزون
        transaction = InventoryTransaction(
            item_id=inventory_item.item_id,
            transaction_type='in',
            quantity=quantity,
            user_id=current_user.user_id,
            notes='إضافة أولية للمخزون'
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        flash('تمت إضافة عنصر المخزون بنجاح', 'success')
        return redirect(url_for('inventory.inventory_list'))
    
    return render_template('inventory/add_inventory.html', products=products)

@inventory.route('/inventory/edit/<int:item_id>', methods=['GET', 'POST'])
@login_required
def edit_inventory(item_id):
    inventory_item = InventoryItem.query.get_or_404(item_id)
    products = Product.query.all()
    
    if request.method == 'POST':
        old_quantity = inventory_item.quantity
        new_quantity = request.form.get('quantity', type=float)
        
        inventory_item.product_id = request.form.get('product_id')
        inventory_item.lot_number = request.form.get('lot_number')
        inventory_item.barcode = request.form.get('barcode')
        inventory_item.quantity = new_quantity
        inventory_item.location = request.form.get('location')
        
        # تحويل التواريخ من النص إلى كائنات تاريخ
        production_date_str = request.form.get('production_date')
        expiry_date_str = request.form.get('expiry_date')
        received_date_str = request.form.get('received_date')
        
        if production_date_str:
            inventory_item.production_date = datetime.strptime(production_date_str, '%Y-%m-%d').date()
        inventory_item.expiry_date = datetime.strptime(expiry_date_str, '%Y-%m-%d').date()
        inventory_item.received_date = datetime.strptime(received_date_str, '%Y-%m-%d').date()
        
        db.session.commit()
        
        # إذا تغيرت الكمية، أضف معاملة
        if old_quantity != new_quantity:
            transaction_type = 'in' if new_quantity > old_quantity else 'out'
            quantity_change = abs(new_quantity - old_quantity)
            
            transaction = InventoryTransaction(
                item_id=inventory_item.item_id,
                transaction_type=transaction_type,
                quantity=quantity_change,
                user_id=current_user.user_id,
                notes='تعديل الكمية'
            )
            
            db.session.add(transaction)
            db.session.commit()
        
        flash('تم تحديث عنصر المخزون بنجاح', 'success')
        return redirect(url_for('inventory.inventory_list'))
    
    return render_template('inventory/edit_inventory.html', 
                          inventory_item=inventory_item,
                          products=products)

@inventory.route('/inventory/delete/<int:item_id>', methods=['POST'])
@login_required
def delete_inventory(item_id):
    inventory_item = InventoryItem.query.get_or_404(item_id)
    
    # حذف المعاملات المرتبطة أولاً
    InventoryTransaction.query.filter_by(item_id=item_id).delete()
    
    db.session.delete(inventory_item)
    db.session.commit()
    flash('تم حذف عنصر المخزون بنجاح', 'success')
    return redirect(url_for('inventory.inventory_list'))

@inventory.route('/inventory/transaction', methods=['GET', 'POST'])
@login_required
def add_transaction():
    inventory_items = InventoryItem.query.join(Product).all()
    
    if request.method == 'POST':
        item_id = request.form.get('item_id')
        transaction_type = request.form.get('transaction_type')
        quantity = request.form.get('quantity', type=float)
        notes = request.form.get('notes')
        
        inventory_item = InventoryItem.query.get_or_404(item_id)
        
        # التحقق من صحة المعاملة
        if transaction_type == 'out' and quantity > inventory_item.quantity:
            flash('الكمية المطلوبة أكبر من الكمية المتوفرة في المخزون', 'danger')
            return redirect(url_for('inventory.add_transaction'))
        
        # تحديث كمية المخزون
        if transaction_type == 'in':
            inventory_item.quantity += quantity
        else:
            inventory_item.quantity -= quantity
        
        # إضافة المعاملة
        transaction = InventoryTransaction(
            item_id=item_id,
            transaction_type=transaction_type,
            quantity=quantity,
            user_id=current_user.user_id,
            notes=notes
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        flash('تمت إضافة المعاملة بنجاح', 'success')
        return redirect(url_for('inventory.inventory_list'))
    
    return render_template('inventory/add_transaction.html', inventory_items=inventory_items)

# إدارة الفئات
@inventory.route('/categories')
@login_required
def categories_list():
    categories = Category.query.all()
    return render_template('inventory/categories_list.html', categories=categories)

@inventory.route('/categories/add', methods=['GET', 'POST'])
@login_required
def add_category():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        category = Category(name=name, description=description)
        db.session.add(category)
        db.session.commit()
        
        flash('تمت إضافة الفئة بنجاح', 'success')
        return redirect(url_for('inventory.categories_list'))
    
    return render_template('inventory/add_category.html')

# إدارة الشركات المصنعة
@inventory.route('/manufacturers')
@login_required
def manufacturers_list():
    manufacturers = Manufacturer.query.all()
    return render_template('inventory/manufacturers_list.html', manufacturers=manufacturers)

@inventory.route('/manufacturers/add', methods=['GET', 'POST'])
@login_required
def add_manufacturer():
    if request.method == 'POST':
        name = request.form.get('name')
        contact_person = request.form.get('contact_person')
        phone = request.form.get('phone')
        email = request.form.get('email')
        website = request.form.get('website')
        notes = request.form.get('notes')
        
        manufacturer = Manufacturer(
            name=name,
            contact_person=contact_person,
            phone=phone,
            email=email,
            website=website,
            notes=notes
        )
        
        db.session.add(manufacturer)
        db.session.commit()
        
        flash('تمت إضافة الشركة المصنعة بنجاح', 'success')
        return redirect(url_for('inventory.manufacturers_list'))
    
    return render_template('inventory/add_manufacturer.html')
