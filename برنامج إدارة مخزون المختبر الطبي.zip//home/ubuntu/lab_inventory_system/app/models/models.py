from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    full_name = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128))
    role = db.Column(db.String(64), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def __init__(self, username, password, full_name, email=None, role='user'):
        self.username = username
        self.password = password
        self.full_name = full_name
        self.email = email
        self.role = role
    
    @property
    def password(self):
        raise AttributeError('كلمة المرور ليست خاصية يمكن قراءتها')
    
    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.user_id)

class Category(db.Model):
    __tablename__ = 'categories'
    
    category_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    
    products = db.relationship('Product', backref='category', lazy='dynamic')

class Manufacturer(db.Model):
    __tablename__ = 'manufacturers'
    
    manufacturer_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    contact_person = db.Column(db.String(128))
    phone = db.Column(db.String(64))
    email = db.Column(db.String(128))
    website = db.Column(db.String(128))
    notes = db.Column(db.Text)
    
    products = db.relationship('Product', backref='manufacturer', lazy='dynamic')

class Product(db.Model):
    __tablename__ = 'products'
    
    product_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    catalog_number = db.Column(db.String(64))
    category_id = db.Column(db.Integer, db.ForeignKey('categories.category_id'))
    manufacturer_id = db.Column(db.Integer, db.ForeignKey('manufacturers.manufacturer_id'))
    unit = db.Column(db.String(32), nullable=False)
    storage_conditions = db.Column(db.String(128))
    min_quantity = db.Column(db.Integer, default=0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    inventory_items = db.relationship('InventoryItem', backref='product', lazy='dynamic')
    
    def current_stock(self):
        """حساب المخزون الحالي للمنتج"""
        total = 0
        for item in self.inventory_items:
            total += item.quantity
        return total
    
    def expiring_soon(self, days=30):
        """الحصول على عناصر المخزون التي ستنتهي قريبًا"""
        from datetime import date, timedelta
        expiry_date = date.today() + timedelta(days=days)
        return self.inventory_items.filter(InventoryItem.expiry_date <= expiry_date, 
                                          InventoryItem.quantity > 0).all()

class InventoryItem(db.Model):
    __tablename__ = 'inventory_items'
    
    item_id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.product_id'), nullable=False)
    lot_number = db.Column(db.String(64), nullable=False)
    barcode = db.Column(db.String(128))
    quantity = db.Column(db.Float, nullable=False)
    location = db.Column(db.String(128))
    production_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date, nullable=False)
    received_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    transactions = db.relationship('InventoryTransaction', backref='inventory_item', lazy='dynamic')
    notifications = db.relationship('Notification', backref='inventory_item', lazy='dynamic')
    
    def is_expired(self):
        """التحقق مما إذا كان العنصر منتهي الصلاحية"""
        from datetime import date
        return self.expiry_date < date.today()
    
    def days_to_expiry(self):
        """حساب عدد الأيام المتبقية حتى انتهاء الصلاحية"""
        from datetime import date
        if self.is_expired():
            return 0
        delta = self.expiry_date - date.today()
        return delta.days

class InventoryTransaction(db.Model):
    __tablename__ = 'inventory_transactions'
    
    transaction_id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('inventory_items.item_id'), nullable=False)
    transaction_type = db.Column(db.String(16), nullable=False)  # 'in' للإضافة، 'out' للسحب
    quantity = db.Column(db.Float, nullable=False)
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    notes = db.Column(db.Text)
    
    user = db.relationship('User', backref='transactions')

class NotificationSetting(db.Model):
    __tablename__ = 'notification_settings'
    
    setting_id = db.Column(db.Integer, primary_key=True)
    days_before_expiry = db.Column(db.Integer, default=30, nullable=False)
    email_notifications = db.Column(db.Boolean, default=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    
    user = db.relationship('User', backref='notification_settings')

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    notification_id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('inventory_items.item_id'), nullable=False)
    notification_type = db.Column(db.String(32), nullable=False)  # 'expiry' للانتهاء، 'low_stock' للمخزون المنخفض
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
