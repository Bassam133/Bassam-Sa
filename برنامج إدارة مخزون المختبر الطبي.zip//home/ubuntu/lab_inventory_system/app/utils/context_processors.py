from flask import Blueprint, render_template, g, request
from flask_login import current_user
from app.models.models import Notification
from app import login_manager
from app.utils.notifications import get_unread_notifications

@login_manager.user_loader
def load_user(user_id):
    from app.models.models import User
    return User.query.get(int(user_id))

main_bp = Blueprint('main_bp', __name__)

@main_bp.before_app_request
def before_request():
    """تنفيذ قبل كل طلب للتطبيق"""
    if current_user.is_authenticated:
        # إضافة التنبيهات غير المقروءة إلى المتغير العام g
        g.notifications = get_unread_notifications()
    else:
        g.notifications = []

@main_bp.app_context_processor
def inject_notifications():
    """حقن التنبيهات في سياق القالب"""
    return dict(notifications=getattr(g, 'notifications', []))
