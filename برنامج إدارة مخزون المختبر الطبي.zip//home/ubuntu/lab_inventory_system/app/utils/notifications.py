from app import db
from app.models.models import InventoryItem, Notification, NotificationSetting, User
from datetime import date, datetime, timedelta
from flask import current_app
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def check_expiring_items():
    """
    فحص العناصر التي ستنتهي صلاحيتها قريبًا وإنشاء تنبيهات لها
    """
    today = date.today()
    
    # الحصول على إعدادات التنبيهات
    settings = NotificationSetting.query.first()
    if not settings:
        # إعدادات افتراضية إذا لم تكن موجودة
        days_before = 30
    else:
        days_before = settings.days_before_expiry
    
    # البحث عن العناصر التي ستنتهي صلاحيتها خلال الفترة المحددة
    expiry_date = today + timedelta(days=days_before)
    
    expiring_items = InventoryItem.query.filter(
        InventoryItem.expiry_date <= expiry_date,
        InventoryItem.expiry_date > today,
        InventoryItem.quantity > 0
    ).all()
    
    # إنشاء تنبيهات للعناصر التي ستنتهي قريبًا
    for item in expiring_items:
        # التحقق من عدم وجود تنبيه سابق لهذا العنصر
        existing_notification = Notification.query.filter_by(
            item_id=item.item_id,
            notification_type='expiry'
        ).first()
        
        if not existing_notification:
            days_remaining = (item.expiry_date - today).days
            
            notification = Notification(
                item_id=item.item_id,
                notification_type='expiry',
                message=f"المنتج {item.product.name} (رقم التشغيلة: {item.lot_number}) سينتهي خلال {days_remaining} يوم"
            )
            
            db.session.add(notification)
    
    # البحث عن العناصر منتهية الصلاحية التي لم يتم التنبيه عنها بعد
    expired_items = InventoryItem.query.filter(
        InventoryItem.expiry_date < today,
        InventoryItem.quantity > 0
    ).all()
    
    # إنشاء تنبيهات للعناصر منتهية الصلاحية
    for item in expired_items:
        # التحقق من عدم وجود تنبيه سابق لهذا العنصر
        existing_notification = Notification.query.filter_by(
            item_id=item.item_id,
            notification_type='expired'
        ).first()
        
        if not existing_notification:
            notification = Notification(
                item_id=item.item_id,
                notification_type='expired',
                message=f"المنتج {item.product.name} (رقم التشغيلة: {item.lot_number}) منتهي الصلاحية"
            )
            
            db.session.add(notification)
    
    db.session.commit()
    
    # إرسال إشعارات بالبريد الإلكتروني إذا كانت الميزة مفعلة
    if settings and settings.email_notifications:
        send_email_notifications()

def check_low_stock():
    """
    فحص المنتجات ذات المخزون المنخفض وإنشاء تنبيهات لها
    """
    from app.models.models import Product
    
    # الحصول على المنتجات التي لديها كمية أقل من الحد الأدنى
    products = Product.query.all()
    
    for product in products:
        current_stock = product.current_stock()
        
        if current_stock < product.min_quantity:
            # التحقق من عدم وجود تنبيه سابق لهذا المنتج
            existing_notification = Notification.query.filter_by(
                item_id=product.inventory_items.first().item_id if product.inventory_items.first() else None,
                notification_type='low_stock'
            ).first()
            
            if not existing_notification and product.inventory_items.first():
                notification = Notification(
                    item_id=product.inventory_items.first().item_id,
                    notification_type='low_stock',
                    message=f"المنتج {product.name} لديه مخزون منخفض ({current_stock} {product.unit})"
                )
                
                db.session.add(notification)
    
    db.session.commit()

def send_email_notifications():
    """
    إرسال إشعارات البريد الإلكتروني للمستخدمين
    """
    # الحصول على التنبيهات غير المقروءة
    notifications = Notification.query.filter_by(is_read=False).all()
    
    if not notifications:
        return
    
    # الحصول على المستخدمين الذين لديهم بريد إلكتروني
    users = User.query.filter(User.email.isnot(None)).all()
    
    if not users:
        return
    
    # إعداد رسالة البريد الإلكتروني
    msg = MIMEMultipart()
    msg['Subject'] = 'تنبيهات نظام إدارة مخزون المختبر الطبي'
    
    # إنشاء محتوى البريد الإلكتروني
    body = "تنبيهات نظام إدارة مخزون المختبر الطبي:\n\n"
    
    for notification in notifications:
        body += f"- {notification.message}\n"
    
    msg.attach(MIMEText(body, 'plain'))
    
    # إرسال البريد الإلكتروني لكل مستخدم
    for user in users:
        try:
            # هذه الوظيفة تحتاج إلى تكوين خادم SMTP
            # في بيئة الإنتاج، يجب تكوين إعدادات البريد الإلكتروني بشكل صحيح
            pass
        except Exception as e:
            current_app.logger.error(f"خطأ في إرسال البريد الإلكتروني: {str(e)}")

def get_unread_notifications():
    """
    الحصول على التنبيهات غير المقروءة
    """
    return Notification.query.filter_by(is_read=False).all()

def mark_notification_as_read(notification_id):
    """
    تحديد التنبيه كمقروء
    """
    notification = Notification.query.get(notification_id)
    if notification:
        notification.is_read = True
        db.session.commit()
        return True
    return False
