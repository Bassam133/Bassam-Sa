const express = require('express');
const pdf = require('html-pdf');
const fs = require('fs');
const path = require('path');

// PDF Report Generator for Web Version
class PDFReportGenerator {
  constructor() {
    this.router = express.Router();
    this.setupRoutes();
  }

  setupRoutes() {
    this.router.post('/generate-inventory-report', this.generateInventoryReport.bind(this));
    this.router.post('/generate-expiring-report', this.generateExpiringReport.bind(this));
    this.router.post('/generate-expired-report', this.generateExpiredReport.bind(this));
    this.router.get('/download/:filename', this.downloadReport.bind(this));
  }

  async generateInventoryReport(req, res) {
    try {
      const { inventory } = req.body;
      
      if (!inventory || !Array.isArray(inventory)) {
        return res.status(400).json({ error: 'Invalid inventory data' });
      }
      
      const reportHtml = this.generateReportHtml(inventory, 'تقرير المخزون الكامل');
      const filename = `inventory_report_${Date.now()}.pdf`;
      const filePath = path.join(__dirname, '../public/reports', filename);
      
      // Ensure directory exists
      if (!fs.existsSync(path.join(__dirname, '../public/reports'))) {
        fs.mkdirSync(path.join(__dirname, '../public/reports'), { recursive: true });
      }
      
      // Generate PDF
      await this.generatePDF(reportHtml, filePath);
      
      res.json({ 
        success: true, 
        filename,
        downloadUrl: `/api/reports/download/${filename}`
      });
    } catch (error) {
      console.error('Error generating inventory report:', error);
      res.status(500).json({ error: 'Failed to generate report' });
    }
  }

  async generateExpiringReport(req, res) {
    try {
      const { inventory } = req.body;
      
      if (!inventory || !Array.isArray(inventory)) {
        return res.status(400).json({ error: 'Invalid inventory data' });
      }
      
      const reportHtml = this.generateReportHtml(inventory, 'تقرير المنتجات قريبة الانتهاء');
      const filename = `expiring_report_${Date.now()}.pdf`;
      const filePath = path.join(__dirname, '../public/reports', filename);
      
      // Ensure directory exists
      if (!fs.existsSync(path.join(__dirname, '../public/reports'))) {
        fs.mkdirSync(path.join(__dirname, '../public/reports'), { recursive: true });
      }
      
      // Generate PDF
      await this.generatePDF(reportHtml, filePath);
      
      res.json({ 
        success: true, 
        filename,
        downloadUrl: `/api/reports/download/${filename}`
      });
    } catch (error) {
      console.error('Error generating expiring report:', error);
      res.status(500).json({ error: 'Failed to generate report' });
    }
  }

  async generateExpiredReport(req, res) {
    try {
      const { inventory } = req.body;
      
      if (!inventory || !Array.isArray(inventory)) {
        return res.status(400).json({ error: 'Invalid inventory data' });
      }
      
      const reportHtml = this.generateReportHtml(inventory, 'تقرير المنتجات منتهية الصلاحية');
      const filename = `expired_report_${Date.now()}.pdf`;
      const filePath = path.join(__dirname, '../public/reports', filename);
      
      // Ensure directory exists
      if (!fs.existsSync(path.join(__dirname, '../public/reports'))) {
        fs.mkdirSync(path.join(__dirname, '../public/reports'), { recursive: true });
      }
      
      // Generate PDF
      await this.generatePDF(reportHtml, filePath);
      
      res.json({ 
        success: true, 
        filename,
        downloadUrl: `/api/reports/download/${filename}`
      });
    } catch (error) {
      console.error('Error generating expired report:', error);
      res.status(500).json({ error: 'Failed to generate report' });
    }
  }

  downloadReport(req, res) {
    const { filename } = req.params;
    const filePath = path.join(__dirname, '../public/reports', filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    res.download(filePath);
  }

  generateReportHtml(data, reportTitle) {
    // Create table rows
    let tableRows = '';
    data.forEach(item => {
      tableRows += `
        <tr>
          <td>${item.product_name}</td>
          <td>${item.lot_number}</td>
          <td>${item.production_date}</td>
          <td>${item.expiry_date}</td>
          <td>${item.quantity}</td>
          <td>${item.location || ''}</td>
        </tr>
      `;
    });
    
    // Generate HTML
    return `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${reportTitle}</title>
        <style>
          body {
            font-family: 'Arial', sans-serif;
            padding: 20px;
            direction: rtl;
          }
          .header {
            text-align: center;
            margin-bottom: 20px;
          }
          .logo {
            max-width: 200px;
            margin-bottom: 10px;
          }
          h1 {
            color: #2c3e50;
            font-size: 24px;
            margin-bottom: 5px;
          }
          .date {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 20px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: right;
          }
          th {
            background-color: #3498db;
            color: white;
          }
          tr:nth-child(even) {
            background-color: #f2f2f2;
          }
          .footer {
            text-align: center;
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 30px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="https://kzovjcfh.manus.space/images/logo.jpeg" class="logo" alt="تجمع القصيم الصحي">
          <h1>نظام إدارة مخزون المختبر الطبي</h1>
          <h2>${reportTitle}</h2>
          <div class="date">تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}</div>
        </div>
        
        <table>
          <thead>
            <tr>
              <th>اسم المنتج</th>
              <th>رقم التشغيلة</th>
              <th>تاريخ الإنتاج</th>
              <th>تاريخ الانتهاء</th>
              <th>الكمية</th>
              <th>الموقع</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
        </table>
        
        <div class="footer">
          <p>© ${new Date().getFullYear()} تجمع القصيم الصحي. جميع الحقوق محفوظة.</p>
        </div>
      </body>
      </html>
    `;
  }

  generatePDF(html, filePath) {
    return new Promise((resolve, reject) => {
      const options = {
        format: 'A4',
        orientation: 'portrait',
        border: {
          top: '10mm',
          right: '10mm',
          bottom: '10mm',
          left: '10mm'
        }
      };
      
      pdf.create(html, options).toFile(filePath, (err, res) => {
        if (err) {
          reject(err);
        } else {
          resolve(res);
        }
      });
    });
  }

  getRouter() {
    return this.router;
  }
}

module.exports = PDFReportGenerator;
