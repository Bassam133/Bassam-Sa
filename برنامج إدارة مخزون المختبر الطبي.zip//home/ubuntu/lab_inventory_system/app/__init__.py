from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
import os

# إنشاء مثيل قاعدة البيانات
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

def create_app():
    # إنشاء تطبيق Flask
    app = Flask(__name__)
    
    # تكوين التطبيق
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev_key_for_development')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///lab_inventory.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # تهيئة الإضافات
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    
    # تسجيل البلوبرنتات
    from app.controllers.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint)
    
    from app.controllers.main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    from app.controllers.inventory import inventory as inventory_blueprint
    app.register_blueprint(inventory_blueprint)
    
    from app.controllers.reports import reports as reports_blueprint
    app.register_blueprint(reports_blueprint)
    
    from app.controllers.notifications import notifications as notifications_blueprint
    app.register_blueprint(notifications_blueprint)
    
    # تسجيل معالجات السياق
    from app.utils.context_processors import main_bp
    app.register_blueprint(main_bp)
    
    return app
