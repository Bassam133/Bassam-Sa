#!/bin/bash

# اختبار وظائف نظام إدارة مخزون المختبر الطبي

echo "بدء اختبار نظام إدارة مخزون المختبر الطبي..."

# إنشاء قاعدة البيانات للاختبار
echo "إنشاء قاعدة البيانات للاختبار..."
cd /home/ubuntu/lab_inventory_system
export FLASK_APP=run.py
python3 -c "from app import create_app, db; app = create_app(); app.app_context().push(); db.create_all()"

if [ $? -ne 0 ]; then
    echo "فشل في إنشاء قاعدة البيانات!"
    exit 1
fi
echo "تم إنشاء قاعدة البيانات بنجاح."

# إضافة مستخدم للاختبار
echo "إضافة مستخدم للاختبار..."
python3 -c "
from app import create_app, db
from app.models.models import User
app = create_app()
with app.app_context():
    # التحقق من عدم وجود المستخدم مسبقاً
    user = User.query.filter_by(username='admin').first()
    if not user:
        user = User(username='admin', password='admin123', full_name='مدير النظام', email='admin@example.com', role='admin')
        db.session.add(user)
        db.session.commit()
        print('تم إنشاء المستخدم بنجاح')
    else:
        print('المستخدم موجود بالفعل')
"

# إضافة بيانات اختبار
echo "إضافة بيانات اختبار..."
python3 -c "
from app import create_app, db
from app.models.models import Category, Manufacturer, Product, InventoryItem, NotificationSetting
from datetime import date, timedelta
app = create_app()
with app.app_context():
    # إضافة إعدادات التنبيهات
    settings = NotificationSetting.query.first()
    if not settings:
        settings = NotificationSetting(days_before_expiry=30, email_notifications=False)
        db.session.add(settings)
    
    # إضافة فئات المنتجات
    categories = [
        Category(name='كواشف', description='كواشف ومواد كيميائية للتحاليل'),
        Category(name='أدوات', description='أدوات وأجهزة مخبرية'),
        Category(name='مستهلكات', description='مواد مستهلكة للمختبر')
    ]
    
    for category in categories:
        existing = Category.query.filter_by(name=category.name).first()
        if not existing:
            db.session.add(category)
    
    # إضافة الشركات المصنعة
    manufacturers = [
        Manufacturer(name='شركة الأجهزة الطبية', contact_person='أحمد محمد', phone='0123456789'),
        Manufacturer(name='شركة المواد الكيميائية', contact_person='سارة أحمد', phone='0123456788')
    ]
    
    for manufacturer in manufacturers:
        existing = Manufacturer.query.filter_by(name=manufacturer.name).first()
        if not existing:
            db.session.add(manufacturer)
    
    db.session.commit()
    
    # الحصول على الفئات والشركات المصنعة
    category1 = Category.query.filter_by(name='كواشف').first()
    category2 = Category.query.filter_by(name='مستهلكات').first()
    manufacturer1 = Manufacturer.query.filter_by(name='شركة الأجهزة الطبية').first()
    manufacturer2 = Manufacturer.query.filter_by(name='شركة المواد الكيميائية').first()
    
    # إضافة المنتجات
    products = [
        Product(name='كاشف جلوكوز', catalog_number='GL-100', category_id=category1.category_id, 
                manufacturer_id=manufacturer2.manufacturer_id, unit='عبوة', min_quantity=5),
        Product(name='أنابيب اختبار', catalog_number='TB-200', category_id=category2.category_id, 
                manufacturer_id=manufacturer1.manufacturer_id, unit='علبة', min_quantity=10),
        Product(name='محلول معايرة', catalog_number='CL-300', category_id=category1.category_id, 
                manufacturer_id=manufacturer2.manufacturer_id, unit='زجاجة', min_quantity=2)
    ]
    
    for product in products:
        existing = Product.query.filter_by(name=product.name).first()
        if not existing:
            db.session.add(product)
    
    db.session.commit()
    
    # الحصول على المنتجات
    product1 = Product.query.filter_by(name='كاشف جلوكوز').first()
    product2 = Product.query.filter_by(name='أنابيب اختبار').first()
    product3 = Product.query.filter_by(name='محلول معايرة').first()
    
    # إضافة عناصر المخزون مع تواريخ مختلفة للانتهاء
    today = date.today()
    
    inventory_items = [
        # منتج منتهي الصلاحية
        InventoryItem(product_id=product1.product_id, lot_number='LOT-001', quantity=10, 
                     production_date=today - timedelta(days=180), 
                     expiry_date=today - timedelta(days=10), 
                     received_date=today - timedelta(days=150)),
        
        # منتج سينتهي قريباً
        InventoryItem(product_id=product2.product_id, lot_number='LOT-002', quantity=20, 
                     production_date=today - timedelta(days=90), 
                     expiry_date=today + timedelta(days=15), 
                     received_date=today - timedelta(days=60)),
        
        # منتج لن ينتهي قريباً
        InventoryItem(product_id=product3.product_id, lot_number='LOT-003', quantity=5, 
                     production_date=today - timedelta(days=30), 
                     expiry_date=today + timedelta(days=150), 
                     received_date=today - timedelta(days=20))
    ]
    
    for item in inventory_items:
        existing = InventoryItem.query.filter_by(product_id=item.product_id, lot_number=item.lot_number).first()
        if not existing:
            db.session.add(item)
    
    db.session.commit()
    print('تم إضافة بيانات الاختبار بنجاح')
"

# اختبار نظام التنبيهات
echo "اختبار نظام التنبيهات..."
python3 -c "
from app import create_app
from app.utils.notifications import check_expiring_items, check_low_stock
app = create_app()
with app.app_context():
    check_expiring_items()
    check_low_stock()
    print('تم اختبار نظام التنبيهات بنجاح')
"

# تشغيل التطبيق للاختبار
echo "تشغيل التطبيق للاختبار..."
echo "يمكنك الوصول إلى التطبيق على العنوان: http://localhost:5000"
echo "اسم المستخدم: admin"
echo "كلمة المرور: admin123"
echo "اضغط Ctrl+C لإيقاف التطبيق عند الانتهاء من الاختبار"

cd /home/ubuntu/lab_inventory_system
python3 run.py
